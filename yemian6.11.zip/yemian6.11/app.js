// ==================== 数据服务抽象层 ====================
// 以后接入后端时，只需将 USE_MOCK 改为 false，并设置 BASE_URL 即可
const ApiService = {
    USE_MOCK: true,
    BASE_URL: '',

    async request(url, options = {}) {
        if (this.USE_MOCK) return null;
        const res = await fetch(this.BASE_URL + url, {
            headers: { 'Content-Type': 'application/json', ...options.headers },
            ...options
        });
        if (!res.ok) throw new Error(`API Error: ${res.status}`);
        return res.json();
    },

    mock: {
        users: {
            admin: { password: 'admin', role: 'admin', name: '管理员' },
            guest: { password: 'guest', role: 'guest', name: '游客' }
        },
        forestConfig: {
            center: [26.65, 106.73],
            boundary: [[26.668,106.710],[26.665,106.725],[26.668,106.740],[26.662,106.752],[26.650,106.755],[26.638,106.750],[26.630,106.740],[26.628,106.725],[26.632,106.712],[26.640,106.708],[26.652,106.705],[26.662,106.708],[26.668,106.710]]
        },
        compartments: [
            {name:'一号林区',coords:[[26.662,106.710],[26.660,106.728],[26.652,106.730],[26.648,106.718],[26.650,106.708]]},
            {name:'二号林区',coords:[[26.660,106.728],[26.662,106.745],[26.650,106.748],[26.648,106.735],[26.652,106.730]]},
            {name:'三号林区',coords:[[26.648,106.718],[26.652,106.730],[26.648,106.735],[26.638,106.730],[26.635,106.720]]},
            {name:'四号林区',coords:[[26.650,106.748],[26.662,106.752],[26.650,106.755],[26.638,106.750],[26.640,106.745]]},
            {name:'五号林区',coords:[[26.638,106.710],[26.648,106.718],[26.635,106.720],[26.630,106.715],[26.632,106.708]]}
        ],
        compartmentColors: ['#00bcd4','#009688','#00acc1','#26a69a','#00897b'],
        rangers: [
            {lat:26.655,lng:106.722,name:'张建国',id:'HL001',area:'一号林区',status:'在线',speed:'2.3km/h',battery:'78%'},
            {lat:26.658,lng:106.728,name:'李明辉',id:'HL002',area:'一号林区',status:'在线',speed:'1.8km/h',battery:'65%'},
            {lat:26.648,lng:106.735,name:'王大山',id:'HL003',area:'二号林区',status:'在线',speed:'3.1km/h',battery:'42%'},
            {lat:26.660,lng:106.740,name:'陈志强',id:'HL004',area:'二号林区',status:'离线',speed:'-',battery:'15%'},
            {lat:26.642,lng:106.718,name:'刘德才',id:'HL005',area:'三号林区',status:'在线',speed:'2.0km/h',battery:'90%'}
        ],
        drones: [
            {lat:26.660,lng:106.730,name:'UAV-01',model:'大疆M300',alt:'120m',heading:'NE',battery:'85%',status:'巡航中'},
            {lat:26.650,lng:106.740,name:'UAV-02',model:'大疆M300',alt:'100m',heading:'SW',battery:'52%',status:'巡航中'},
            {lat:26.645,lng:106.720,name:'UAV-03',model:'大疆M350',alt:'150m',heading:'E',battery:'92%',status:'巡航中'}
        ],
        fires: [
            {lat:26.656,lng:106.732,name:'F001',level:'一般',area:'一号林区',time:'14:23',status:'处置中'},
            {lat:26.643,lng:106.718,name:'F002',level:'较大',area:'三号林区',time:'15:07',status:'处置中'},
            {lat:26.641,lng:106.745,name:'F003',level:'一般',area:'四号林区',time:'16:35',status:'已派发'}
        ],
        pests: [
            {lat:26.652,lng:106.725,area:'一号林区',areaSize:'5.2亩'},
            {lat:26.648,lng:106.738,area:'二号林区',areaSize:'3.8亩'},
            {lat:26.640,lng:106.715,area:'三号林区',areaSize:'8.1亩'},
            {lat:26.655,lng:106.742,area:'四号林区',areaSize:'2.4亩'},
            {lat:26.637,lng:106.728,area:'五号林区',areaSize:'6.5亩'},
            {lat:26.658,lng:106.720,area:'一号林区',areaSize:'1.8亩'},
            {lat:26.643,lng:106.735,area:'二号林区',areaSize:'4.2亩'}
        ],
        patrolRoutes: [
            {coords:[[26.652,106.718],[26.654,106.720],[26.656,106.724],[26.655,106.728]],person:'张建国',date:'2026-06-08',distance:'6.2km'},
            {coords:[[26.648,106.732],[26.650,106.735],[26.646,106.738]],person:'王大山',date:'2026-06-08',distance:'4.8km'}
        ],
        fireImageData: [
            { id:'F001', area:'三号林区', label:'三号林区火情', source:'无人机UAV-03', time:'15:07', result:'高危 - 明火', level:'high', lat:'26.643000', lng:'106.718000', svgType:'fire' },
            { id:'F002', area:'一号林区', label:'一号林区火情', source:'护林员张建国', time:'14:23', result:'高危 - 明火', level:'high', lat:'26.656000', lng:'106.732000', svgType:'fire' },
            { id:'F003', area:'二号林区', label:'二号林区烟雾', source:'无人机UAV-01', time:'13:50', result:'疑似 - 烟雾', level:'mid', lat:'26.648000', lng:'106.735000', svgType:'smoke' },
            { id:'F004', area:'二号林区', label:'二号林区巡护', source:'护林员李明辉', time:'12:15', result:'正常', level:'low', lat:'26.660000', lng:'106.740000', svgType:'normal' },
            { id:'F005', area:'四号林区', label:'四号林区明火', source:'无人机UAV-03', time:'11:30', result:'高危 - 明火', level:'high', lat:'26.641000', lng:'106.745000', svgType:'fire' },
            { id:'F006', area:'一号林区', label:'一号林区余火', source:'护林员王大山', time:'10:45', result:'疑似 - 余烬', level:'mid', lat:'26.658000', lng:'106.728000', svgType:'smoke' },
            { id:'F007', area:'五号林区', label:'五号林区巡护', source:'护林员陈志强', time:'09:50', result:'正常', level:'low', lat:'26.635000', lng:'106.750000', svgType:'normal' },
            { id:'F008', area:'三号林区', label:'三号林区热源', source:'无人机UAV-02', time:'09:10', result:'疑似 - 热源', level:'mid', lat:'26.645000', lng:'106.720000', svgType:'smoke' },
            { id:'F009', area:'一号林区', label:'一号林区过火', source:'无人机UAV-01', time:'08:30', result:'高危 - 过火区', level:'high', lat:'26.654000', lng:'106.730000', svgType:'fire' },
            { id:'F010', area:'四号林区', label:'四号林区巡护', source:'护林员刘德才', time:'08:00', result:'正常', level:'low', lat:'26.639000', lng:'106.742000', svgType:'normal' },
            { id:'F011', area:'二号林区', label:'二号林区暗火', source:'无人机UAV-03', time:'07:20', result:'疑似 - 暗火', level:'mid', lat:'26.650000', lng:'106.736000', svgType:'smoke' },
            { id:'F012', area:'五号林区', label:'五号林区火情', source:'护林员张建国', time:'16:10', result:'高危 - 明火', level:'high', lat:'26.633000', lng:'106.748000', svgType:'fire' },
            { id:'F013', area:'三号林区', label:'三号林区巡护', source:'护林员李明辉', time:'16:40', result:'正常', level:'low', lat:'26.647000', lng:'106.722000', svgType:'normal' },
            { id:'F014', area:'一号林区', label:'一号林区烟雾', source:'无人机UAV-02', time:'17:05', result:'疑似 - 烟雾', level:'mid', lat:'26.659000', lng:'106.726000', svgType:'smoke' },
            { id:'F015', area:'四号林区', label:'四号林区复燃', source:'护林员王大山', time:'17:30', result:'高危 - 复燃', level:'high', lat:'26.640000', lng:'106.744000', svgType:'fire' },
            { id:'F016', area:'五号林区', label:'五号林区巡护', source:'护林员陈志强', time:'17:55', result:'正常', level:'low', lat:'26.634000', lng:'106.752000', svgType:'normal' },
            { id:'F017', area:'二号林区', label:'二号林区火情', source:'无人机UAV-01', time:'18:10', result:'高危 - 明火', level:'high', lat:'26.651000', lng:'106.738000', svgType:'fire' },
            { id:'F018', area:'三号林区', label:'三号林区余烟', source:'护林员刘德才', time:'18:35', result:'疑似 - 余烟', level:'mid', lat:'26.646000', lng:'106.724000', svgType:'smoke' },
            { id:'F019', area:'一号林区', label:'一号林区巡护', source:'护林员张建国', time:'19:00', result:'正常', level:'low', lat:'26.655000', lng:'106.729000', svgType:'normal' },
            { id:'F020', area:'四号林区', label:'四号林区巡护', source:'无人机UAV-03', time:'19:20', result:'正常', level:'low', lat:'26.638000', lng:'106.746000', svgType:'normal' },
            { id:'F021', area:'五号林区', label:'五号林区热源', source:'无人机UAV-02', time:'19:45', result:'疑似 - 热源', level:'mid', lat:'26.632000', lng:'106.749000', svgType:'smoke' },
            { id:'F022', area:'二号林区', label:'二号林区巡护', source:'护林员李明辉', time:'20:00', result:'正常', level:'low', lat:'26.649000', lng:'106.737000', svgType:'normal' },
            { id:'F023', area:'三号林区', label:'三号林区明火', source:'无人机UAV-01', time:'20:20', result:'高危 - 明火', level:'high', lat:'26.644000', lng:'106.721000', svgType:'fire' },
            { id:'F024', area:'一号林区', label:'一号林区巡护', source:'护林员王大山', time:'20:40', result:'正常', level:'low', lat:'26.657000', lng:'106.731000', svgType:'normal' },
            { id:'F025', area:'四号林区', label:'四号林区烟雾', source:'护林员陈志强', time:'21:00', result:'疑似 - 烟雾', level:'mid', lat:'26.637000', lng:'106.743000', svgType:'smoke' },
            { id:'F026', area:'五号林区', label:'五号林区火情', source:'无人机UAV-03', time:'21:15', result:'高危 - 明火', level:'high', lat:'26.631000', lng:'106.751000', svgType:'fire' },
            { id:'F027', area:'二号林区', label:'二号林区巡护', source:'护林员刘德才', time:'21:30', result:'正常', level:'low', lat:'26.652000', lng:'106.739000', svgType:'normal' },
            { id:'F028', area:'三号林区', label:'三号林区巡护', source:'护林员张建国', time:'21:45', result:'正常', level:'low', lat:'26.648000', lng:'106.723000', svgType:'normal' },
            { id:'F029', area:'一号林区', label:'一号林区余火', source:'无人机UAV-02', time:'22:00', result:'疑似 - 余烬', level:'mid', lat:'26.653000', lng:'106.727000', svgType:'smoke' },
            { id:'F030', area:'四号林区', label:'四号林区明火', source:'护林员李明辉', time:'22:15', result:'高危 - 明火', level:'high', lat:'26.636000', lng:'106.745000', svgType:'fire' },
            { id:'F031', area:'五号林区', label:'五号林区巡护', source:'护林员王大山', time:'22:30', result:'正常', level:'low', lat:'26.630000', lng:'106.753000', svgType:'normal' },
            { id:'F032', area:'二号林区', label:'二号林区巡护', source:'无人机UAV-01', time:'22:45', result:'正常', level:'low', lat:'26.650000', lng:'106.740000', svgType:'normal' }
        ],
        pestImageData: [
            { id:'P001', area:'一号林区', label:'一号林区枯死松树', source:'无人机UAV-02', time:'10:30', result:'高危 - 松材线虫病', level:'high', lat:'26.652000', lng:'106.725000', svgType:'dead' },
            { id:'P002', area:'二号林区', label:'二号林区感染松树', source:'护林员王大山', time:'09:15', result:'高危 - 松材线虫病', level:'high', lat:'26.648000', lng:'106.738000', svgType:'dead' },
            { id:'P003', area:'三号林区', label:'三号林区变色木', source:'无人机UAV-01', time:'08:40', result:'疑似 - 变色', level:'mid', lat:'26.640000', lng:'106.715000', svgType:'sick' },
            { id:'P004', area:'四号林区', label:'四号林区巡护', source:'护林员刘德才', time:'07:50', result:'正常', level:'low', lat:'26.655000', lng:'106.742000', svgType:'normal' },
            { id:'P005', area:'一号林区', label:'一号林区枯死木', source:'护林员张建国', time:'10:00', result:'高危 - 松材线虫病', level:'high', lat:'26.653000', lng:'106.722000', svgType:'dead' },
            { id:'P006', area:'五号林区', label:'五号林区变色', source:'无人机UAV-03', time:'09:30', result:'疑似 - 变色', level:'mid', lat:'26.633000', lng:'106.750000', svgType:'sick' },
            { id:'P007', area:'二号林区', label:'二号林区巡护', source:'护林员李明辉', time:'08:50', result:'正常', level:'low', lat:'26.649000', lng:'106.736000', svgType:'normal' },
            { id:'P008', area:'三号林区', label:'三号林区枯死木', source:'无人机UAV-02', time:'08:10', result:'高危 - 松材线虫病', level:'high', lat:'26.641000', lng:'106.718000', svgType:'dead' },
            { id:'P009', area:'四号林区', label:'四号林区疑似', source:'护林员王大山', time:'07:30', result:'疑似 - 变色', level:'mid', lat:'26.656000', lng:'106.744000', svgType:'sick' },
            { id:'P010', area:'一号林区', label:'一号林区巡护', source:'护林员陈志强', time:'07:00', result:'正常', level:'low', lat:'26.654000', lng:'106.726000', svgType:'normal' },
            { id:'P011', area:'五号林区', label:'五号林区枯死松', source:'无人机UAV-01', time:'11:00', result:'高危 - 松材线虫病', level:'high', lat:'26.632000', lng:'106.748000', svgType:'dead' },
            { id:'P012', area:'二号林区', label:'二号林区变色', source:'护林员刘德才', time:'10:20', result:'疑似 - 变色', level:'mid', lat:'26.647000', lng:'106.740000', svgType:'sick' },
            { id:'P013', area:'三号林区', label:'三号林区巡护', source:'护林员张建国', time:'09:45', result:'正常', level:'low', lat:'26.642000', lng:'106.716000', svgType:'normal' },
            { id:'P014', area:'四号林区', label:'四号林区枯死木', source:'无人机UAV-03', time:'09:00', result:'高危 - 松材线虫病', level:'high', lat:'26.657000', lng:'106.746000', svgType:'dead' },
            { id:'P015', area:'一号林区', label:'一号林区疑似', source:'护林员李明辉', time:'08:25', result:'疑似 - 变色', level:'mid', lat:'26.651000', lng:'106.724000', svgType:'sick' },
            { id:'P016', area:'五号林区', label:'五号林区巡护', source:'护林员王大山', time:'07:40', result:'正常', level:'low', lat:'26.634000', lng:'106.752000', svgType:'normal' },
            { id:'P017', area:'二号林区', label:'二号林区枯死松', source:'无人机UAV-02', time:'11:20', result:'高危 - 松材线虫病', level:'high', lat:'26.646000', lng:'106.737000', svgType:'dead' },
            { id:'P018', area:'三号林区', label:'三号林区变色', source:'护林员陈志强', time:'10:50', result:'疑似 - 变色', level:'mid', lat:'26.643000', lng:'106.719000', svgType:'sick' },
            { id:'P019', area:'四号林区', label:'四号林区巡护', source:'护林员刘德才', time:'10:10', result:'正常', level:'low', lat:'26.658000', lng:'106.745000', svgType:'normal' },
            { id:'P020', area:'一号林区', label:'一号林区巡护', source:'无人机UAV-01', time:'09:35', result:'正常', level:'low', lat:'26.655000', lng:'106.727000', svgType:'normal' },
            { id:'P021', area:'五号林区', label:'五号林区疑似', source:'护林员张建国', time:'08:55', result:'疑似 - 变色', level:'mid', lat:'26.631000', lng:'106.749000', svgType:'sick' },
            { id:'P022', area:'二号林区', label:'二号林区巡护', source:'护林员李明辉', time:'08:15', result:'正常', level:'low', lat:'26.650000', lng:'106.739000', svgType:'normal' },
            { id:'P023', area:'三号林区', label:'三号林区枯死松', source:'无人机UAV-03', time:'07:45', result:'高危 - 松材线虫病', level:'high', lat:'26.644000', lng:'106.717000', svgType:'dead' },
            { id:'P024', area:'四号林区', label:'四号林区变色', source:'护林员王大山', time:'07:10', result:'疑似 - 变色', level:'mid', lat:'26.659000', lng:'106.747000', svgType:'sick' },
            { id:'P025', area:'一号林区', label:'一号林区枯死木', source:'护林员陈志强', time:'11:40', result:'高危 - 松材线虫病', level:'high', lat:'26.650000', lng:'106.723000', svgType:'dead' },
            { id:'P026', area:'五号林区', label:'五号林区巡护', source:'护林员刘德才', time:'11:10', result:'正常', level:'low', lat:'26.635000', lng:'106.751000', svgType:'normal' },
            { id:'P027', area:'二号林区', label:'二号林区枯死松', source:'无人机UAV-02', time:'10:40', result:'高危 - 松材线虫病', level:'high', lat:'26.645000', lng:'106.735000', svgType:'dead' },
            { id:'P028', area:'三号林区', label:'三号林区巡护', source:'护林员张建国', time:'10:05', result:'正常', level:'low', lat:'26.639000', lng:'106.720000', svgType:'normal' },
            { id:'P029', area:'四号林区', label:'四号林区枯死木', source:'无人机UAV-01', time:'09:20', result:'高危 - 松材线虫病', level:'high', lat:'26.660000', lng:'106.743000', svgType:'dead' },
            { id:'P030', area:'一号林区', label:'一号林区巡护', source:'护林员李明辉', time:'08:35', result:'正常', level:'low', lat:'26.656000', lng:'106.728000', svgType:'normal' },
            { id:'P031', area:'五号林区', label:'五号林区变色', source:'护林员王大山', time:'07:55', result:'疑似 - 变色', level:'mid', lat:'26.629000', lng:'106.754000', svgType:'sick' },
            { id:'P032', area:'二号林区', label:'二号林区巡护', source:'无人机UAV-03', time:'07:20', result:'正常', level:'low', lat:'26.651000', lng:'106.741000', svgType:'normal' }
        ],
        firePointData: {
            F001: { id:'F001', level:'较大', area:'三号林区', time:'15:07', status:'蔓延中', lng:'106.718000', lat:'26.643000', wind:'东北风 3级', spread:'向西南蔓延', speed:'1.2 km/h', affected:'52亩', response:'已派遣巡护二队前往处置，无人机UAV-03正在现场监控', commander:'刘德才', forces:'巡护二队6人 + 应急突击队4人' },
            F002: { id:'F002', level:'一般', area:'一号林区', time:'14:23', status:'控制中', lng:'106.732000', lat:'26.656000', wind:'东北风 2级', spread:'向西南缓慢蔓延', speed:'0.5 km/h', affected:'18亩', response:'护林员张建国现场处置中，火势已基本控制', commander:'张建国', forces:'护林员2人' },
            F003: { id:'F003', level:'一般', area:'四号林区', time:'16:35', status:'已派发', lng:'106.745000', lat:'26.641000', wind:'东风 2级', spread:'向西蔓延', speed:'0.8 km/h', affected:'16亩', response:'已派发巡护任务，护林员正在赶往现场', commander:'待指派', forces:'待调配' }
        },
        riskAssessment: {
            summary: { total: 15, high: 3, mid: 5, low: 7 },
            items: [
                { id:'RA001', area:'一号林区', type:'森林火灾', level:'high', score: 87.5, desc:'近期高温干燥，火险等级极高', time:'2026-06-10 08:00', status:'预警中' },
                { id:'RA002', area:'三号林区', type:'松材线虫病', level:'high', score: 82.3, desc:'病虫害扩散趋势明显', time:'2026-06-10 08:00', status:'预警中' },
                { id:'RA003', area:'二号林区', type:'森林火灾', level:'high', score: 79.1, desc:'连续高温预警，火险等级较高', time:'2026-06-10 08:00', status:'预警中' },
                { id:'RA004', area:'四号林区', type:'地质灾害', level:'mid', score: 65.4, desc:'近期降雨较多，山体滑坡风险', time:'2026-06-10 08:00', status:'监控中' },
                { id:'RA005', area:'五号林区', type:'松材线虫病', level:'mid', score: 58.7, desc:'发现疑似感染树木', time:'2026-06-10 08:00', status:'监控中' },
                { id:'RA006', area:'一号林区', type:'盗伐风险', level:'mid', score: 52.3, desc:'偏远区域巡护覆盖不足', time:'2026-06-10 08:00', status:'监控中' },
                { id:'RA007', area:'二号林区', type:'地质灾害', level:'mid', score: 48.9, desc:'低洼区域积水风险', time:'2026-06-10 08:00', status:'监控中' },
                { id:'RA008', area:'三号林区', type:'盗伐风险', level:'mid', score: 45.2, desc:'边界区域监控盲区', time:'2026-06-10 08:00', status:'监控中' },
                { id:'RA009', area:'四号林区', type:'森林火灾', level:'low', score: 32.1, desc:'火险等级一般', time:'2026-06-10 08:00', status:'已解除' },
                { id:'RA010', area:'五号林区', type:'地质灾害', level:'low', score: 28.5, desc:'风险较低', time:'2026-06-10 08:00', status:'已解除' }
            ]
        },
        abnormalEvents: [
            { id:'AE001', type:'fire', area:'一号林区', desc:'发现明火', level:'high', time:'2026-06-10 14:23', status:'处置中', handler:'张建国' },
            { id:'AE002', type:'pest', area:'二号林区', desc:'松材线虫病感染', level:'high', time:'2026-06-09 10:30', status:'处置中', handler:'王大山' },
            { id:'AE003', type:'fire', area:'三号林区', desc:'烟雾疑似', level:'mid', time:'2026-06-10 15:07', status:'已派发', handler:'刘德才' },
            { id:'AE004', type:'geo', area:'四号林区', desc:'山体裂缝', level:'mid', time:'2026-06-08 09:00', status:'监控中', handler:'陈志强' },
            { id:'AE005', type:'theft', area:'五号林区', desc:'疑似盗伐痕迹', level:'low', time:'2026-06-07 16:20', status:'已处置', handler:'李明辉' }
        ],
        patrolStats: {
            totalPatrols: 24, totalDistance: 136.8, totalDuration: 48.5,
            dailyTrend: [18,22,20,24,26,23,24],
            weeklyTrend: [120,135,128,142,136,130,138],
            areaDistribution: [
                { area:'一号林区', count: 6, distance: 38.2 },
                { area:'二号林区', count: 5, distance: 32.5 },
                { area:'三号林区', count: 5, distance: 28.1 },
                { area:'四号林区', count: 4, distance: 22.0 },
                { area:'五号林区', count: 4, distance: 16.0 }
            ]
        },
        performanceRanking: [
            { rank:1, name:'张建国', id:'HL001', patrols:28, distance:86.5, duration:32.4, score:95.2, area:'一号林区' },
            { rank:2, name:'刘德才', id:'HL005', patrols:25, distance:78.3, duration:29.8, score:91.7, area:'三号林区' },
            { rank:3, name:'李明辉', id:'HL002', patrols:23, distance:72.1, duration:27.5, score:88.4, area:'一号林区' },
            { rank:4, name:'王大山', id:'HL003', patrols:21, distance:65.8, duration:25.2, score:84.1, area:'二号林区' },
            { rank:5, name:'陈志强', id:'HL004', patrols:18, distance:52.4, duration:20.6, score:76.3, area:'二号林区' }
        ],
        droneStats: {
            totalFlights: 42, totalDuration: 126.5, totalDistance: 892.3,
            fleet: [
                { name:'UAV-01', model:'大疆M300', flights:16, duration:48.2, distance:342.1, status:'巡航中' },
                { name:'UAV-02', model:'大疆M300', flights:14, duration:42.5, distance:298.7, status:'巡航中' },
                { name:'UAV-03', model:'大疆M350', flights:12, duration:35.8, distance:251.5, status:'巡航中' }
            ]
        },
        disasterStats: {
            fireCount: 3, pestCount: 7, geoCount: 2, totalAffected: 128.5,
            monthlyTrend: [2,1,3,2,4,3,3,5,2,1,2,3],
            typeDistribution: [
                { type:'森林火灾', count:3, affected:86 },
                { type:'松材线虫病', count:7, affected:32.5 },
                { type:'地质灾害', count:2, affected:10 }
            ]
        },
        usersList: [
            { id:'U001', username:'admin', name:'管理员', role:'admin', status:'在线', lastLogin:'2026-06-10 08:00' },
            { id:'U002', username:'zhangjg', name:'张建国', role:'ranger', status:'在线', lastLogin:'2026-06-10 07:30' },
            { id:'U003', username:'limh', name:'李明辉', role:'ranger', status:'在线', lastLogin:'2026-06-10 07:45' },
            { id:'U004', username:'wangds', name:'王大山', role:'ranger', status:'在线', lastLogin:'2026-06-10 08:15' },
            { id:'U005', username:'chenzq', name:'陈志强', role:'ranger', status:'离线', lastLogin:'2026-06-09 17:30' },
            { id:'U006', username:'liudc', name:'刘德才', role:'ranger', status:'在线', lastLogin:'2026-06-10 07:50' },
            { id:'U007', username:'guest', name:'游客', role:'guest', status:'在线', lastLogin:'2026-06-10 09:00' }
        ],
        roles: [
            { id:'R001', name:'admin', label:'系统管理员', desc:'拥有系统全部权限', userCount:1 },
            { id:'R002', name:'ranger', label:'护林员', desc:'巡护监控与数据上报权限', userCount:5 },
            { id:'R003', name:'guest', label:'游客', desc:'仅查看驾驶舱与统计报表', userCount:1 }
        ],
        permissions: [
            { module:'综合驾驶舱', admin:true, ranger:true, guest:true },
            { module:'巡护监控与管理', admin:true, ranger:true, guest:false },
            { module:'空间分析', admin:true, ranger:true, guest:false },
            { module:'灾害识别处置', admin:true, ranger:true, guest:false },
            { module:'统计报表', admin:true, ranger:true, guest:true },
            { module:'系统管理', admin:true, ranger:false, guest:false }
        ],
        mapServices: [
            { id:'MS001', name:'CartoDB Dark', url:'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', type:'XYZ', status:'正常' },
            { id:'MS002', name:'高德卫星', url:'https://webst0{s}.is.autonavi.com/appmaptile?style=6', type:'XYZ', status:'正常' },
            { id:'MS003', name:'天地图', url:'https://t{s}.tianditu.gov.cn/img_w/wmts', type:'WMTS', status:'正常' }
        ],
        dataOps: {
            lastBackup: '2026-06-10 03:00',
            backupSize: '2.3 GB',
            dbStatus: '正常',
            storageUsed: '68.5%',
            recentOps: [
                { time:'2026-06-10 03:00', type:'自动备份', status:'成功', size:'2.3 GB' },
                { time:'2026-06-09 03:00', type:'自动备份', status:'成功', size:'2.2 GB' },
                { time:'2026-06-08 15:30', type:'数据导入', status:'成功', size:'156 MB' },
                { time:'2026-06-08 03:00', type:'自动备份', status:'成功', size:'2.2 GB' },
                { time:'2026-06-07 03:00', type:'自动备份', status:'成功', size:'2.1 GB' }
            ]
        },
        logs: [
            { time:'2026-06-10 09:15', user:'管理员', action:'登录系统', module:'认证', ip:'192.168.1.100' },
            { time:'2026-06-10 09:10', user:'张建国', action:'上报巡护数据', module:'巡护管理', ip:'192.168.1.101' },
            { time:'2026-06-10 08:45', user:'系统', action:'自动备份完成', module:'数据运维', ip:'-' },
            { time:'2026-06-10 08:30', user:'李明辉', action:'查看火情详情', module:'灾害识别', ip:'192.168.1.102' },
            { time:'2026-06-10 08:00', user:'管理员', action:'修改权限配置', module:'系统管理', ip:'192.168.1.100' },
            { time:'2026-06-09 17:30', user:'陈志强', action:'退出系统', module:'认证', ip:'192.168.1.103' },
            { time:'2026-06-09 17:00', user:'王大山', action:'上报异常事件', module:'巡护管理', ip:'192.168.1.104' },
            { time:'2026-06-09 16:30', user:'系统', action:'风险预警触发', module:'风险预警', ip:'-' }
        ],
        systemMonitor: {
            cpu: 32.5, memory: 58.2, disk: 68.5, network: 12.8,
            uptime: '15天 8小时',
            services: [
                { name:'Web服务', status:'运行中', port:80, cpu:8.2, memory:12.5 },
                { name:'数据库', status:'运行中', port:3306, cpu:15.3, memory:25.8 },
                { name:'地图服务', status:'运行中', port:8080, cpu:5.1, memory:10.2 },
                { name:'消息队列', status:'运行中', port:5672, cpu:3.9, memory:9.7 }
            ]
        }
    },

    // ===== 接口方法：以后接入后端时，只需修改这些方法 =====
    async login(username, password) {
        if (this.USE_MOCK) {
            const user = this.mock.users[username];
            if (user && user.password === password) {
                return { success: true, data: { username, role: user.role, name: user.name } };
            }
            return { success: false, data: null };
        }
        return this.request('/api/auth/login', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });
    },

    async getForestConfig() {
        if (this.USE_MOCK) return this.mock.forestConfig;
        return this.request('/api/forest/config');
    },

    async getCompartments() {
        if (this.USE_MOCK) return this.mock.compartments;
        return this.request('/api/forest/compartments');
    },

    async getCompartmentColors() {
        if (this.USE_MOCK) return this.mock.compartmentColors;
        return this.request('/api/forest/compartments/colors');
    },

    async getRangers() {
        if (this.USE_MOCK) return this.mock.rangers;
        return this.request('/api/rangers');
    },

    async getDrones() {
        if (this.USE_MOCK) return this.mock.drones;
        return this.request('/api/drones');
    },

    async getFires() {
        if (this.USE_MOCK) return this.mock.fires;
        return this.request('/api/fires');
    },

    async getPests() {
        if (this.USE_MOCK) return this.mock.pests;
        return this.request('/api/pests');
    },

    async getPatrolRoutes() {
        if (this.USE_MOCK) return this.mock.patrolRoutes;
        return this.request('/api/patrol/routes');
    },

    async getFireRecognition() {
        if (this.USE_MOCK) return this.mock.fireImageData;
        return this.request('/api/recognition/fire');
    },

    async getPestRecognition() {
        if (this.USE_MOCK) return this.mock.pestImageData;
        return this.request('/api/recognition/pest');
    },

    async analyzeImage(imageData) {
        if (this.USE_MOCK) {
            return { success: true, result: '疑似 - 烟雾', confidence: 78.5, level: 'mid' };
        }
        return this.request('/api/recognition/analyze', {
            method: 'POST',
            body: JSON.stringify({ image: imageData })
        });
    },

    async getFirePoint(id) {
        if (this.USE_MOCK) return this.mock.firePointData[id] || null;
        return this.request('/api/fires/' + id);
    },
    async getFirePoints() {
        if (this.USE_MOCK) return this.mock.firePointData;
        return this.request('/api/fires/points');
    },

    async getStatsOverview() {
        if (this.USE_MOCK) {
            return {
                patrolCount: 24, onlineRangers: 18, onlineDrones: 6,
                patrolDistance: 136.8, patrolDuration: 48.5, taskCount: 32,
                fireCount: 3, pestCount: 7, abnormalCount: 12, unhandledCount: 5
            };
        }
        return this.request('/api/stats/overview');
    },

    // ===== 风险预警 =====
    async getRiskAssessment(params) {
        if (this.USE_MOCK) return this.mock.riskAssessment;
        return this.request('/api/risk/assessment?' + new URLSearchParams(params));
    },

    // ===== 异常事件 =====
    async getAbnormalEvents(type) {
        if (this.USE_MOCK) return this.mock.abnormalEvents;
        return this.request('/api/abnormal-events' + (type ? '?type=' + type : ''));
    },
    async createAbnormalEvent(data) {
        if (this.USE_MOCK) return { success: true, id: 'E' + Date.now() };
        return this.request('/api/abnormal-events', { method: 'POST', body: JSON.stringify(data) });
    },

    // ===== 统计报表 =====
    async getPatrolStats(period) {
        if (this.USE_MOCK) return this.mock.patrolStats;
        return this.request('/api/stats/patrol?' + new URLSearchParams({ period }));
    },
    async getPerformanceRanking(period) {
        if (this.USE_MOCK) return this.mock.performanceRanking;
        return this.request('/api/stats/performance?' + new URLSearchParams({ period }));
    },
    async getDroneStats(period) {
        if (this.USE_MOCK) return this.mock.droneStats;
        return this.request('/api/stats/drones?' + new URLSearchParams({ period }));
    },
    async getDisasterStats(period) {
        if (this.USE_MOCK) return this.mock.disasterStats;
        return this.request('/api/stats/disaster?' + new URLSearchParams({ period }));
    },
    async exportReport(type, format) {
        if (this.USE_MOCK) return { success: true, url: '#mock-export-' + type + '.' + format };
        return this.request('/api/stats/export', { method: 'POST', body: JSON.stringify({ type, format }) });
    },

    // ===== 用户管理 =====
    async getUsers() {
        if (this.USE_MOCK) return this.mock.usersList;
        return this.request('/api/users');
    },
    async createUser(data) {
        if (this.USE_MOCK) return { success: true, id: 'U' + Date.now() };
        return this.request('/api/users', { method: 'POST', body: JSON.stringify(data) });
    },
    async updateUser(id, data) {
        if (this.USE_MOCK) return { success: true };
        return this.request('/api/users/' + id, { method: 'PUT', body: JSON.stringify(data) });
    },
    async deleteUser(id) {
        if (this.USE_MOCK) return { success: true };
        return this.request('/api/users/' + id, { method: 'DELETE' });
    },

    // ===== 角色管理 =====
    async getRoles() {
        if (this.USE_MOCK) return this.mock.roles;
        return this.request('/api/roles');
    },
    async createRole(data) {
        if (this.USE_MOCK) return { success: true, id: 'R' + Date.now() };
        return this.request('/api/roles', { method: 'POST', body: JSON.stringify(data) });
    },
    async updateRole(id, data) {
        if (this.USE_MOCK) return { success: true };
        return this.request('/api/roles/' + id, { method: 'PUT', body: JSON.stringify(data) });
    },
    async deleteRole(id) {
        if (this.USE_MOCK) return { success: true };
        return this.request('/api/roles/' + id, { method: 'DELETE' });
    },

    // ===== 权限管理 =====
    async getPermissions() {
        if (this.USE_MOCK) return this.mock.permissions;
        return this.request('/api/permissions');
    },
    async updatePermission(roleId, data) {
        if (this.USE_MOCK) return { success: true };
        return this.request('/api/permissions/' + roleId, { method: 'PUT', body: JSON.stringify(data) });
    },

    // ===== 地图服务 =====
    async getMapServices() {
        if (this.USE_MOCK) return this.mock.mapServices;
        return this.request('/api/system/map-services');
    },

    // ===== 数据运维 =====
    async getDataOps() {
        if (this.USE_MOCK) return this.mock.dataOps;
        return this.request('/api/system/data-ops');
    },
    async backupData(type) {
        if (this.USE_MOCK) return { success: true, id: 'BK' + Date.now() };
        return this.request('/api/system/backup', { method: 'POST', body: JSON.stringify({ type }) });
    },
    async importData(data) {
        if (this.USE_MOCK) return { success: true, id: 'IMP' + Date.now() };
        return this.request('/api/system/import', { method: 'POST', body: JSON.stringify(data) });
    },

    // ===== 日志管理 =====
    async getLogs(params) {
        if (this.USE_MOCK) return this.mock.logs;
        return this.request('/api/system/logs?' + new URLSearchParams(params || {}));
    },

    // ===== 系统监控 =====
    async getSystemMonitor() {
        if (this.USE_MOCK) return this.mock.systemMonitor;
        return this.request('/api/system/monitor');
    }
};

// ==================== 登录与权限控制 ====================
let currentUser = null;

// 检查登录状态
function checkAuth() {
    const saved = localStorage.getItem('fps_user');
    if (saved) {
        try {
            currentUser = JSON.parse(saved);
            applyRole();
            hideLogin();
        } catch(e) { localStorage.removeItem('fps_user'); }
    }
}

function hideLogin() {
    document.getElementById('loginOverlay').classList.add('hidden');
}

function showLogin() {
    document.getElementById('loginOverlay').classList.remove('hidden');
}

async function doLogin(username, password) {
    const result = await ApiService.login(username, password);
    if (result.success) {
        currentUser = result.data;
        localStorage.setItem('fps_user', JSON.stringify(currentUser));
        document.getElementById('loginError').textContent = '';
        location.reload();
        return true;
    }
    return false;
}

function doLogout() {
    currentUser = null;
    localStorage.removeItem('fps_user');
    document.getElementById('loginUsername').value = '';
    document.getElementById('loginPassword').value = '';
    showLogin();
}

// 根据角色调整界面
function applyRole() {
    if (!currentUser) return;
    const userInfo = document.querySelector('.user-info');
    if (userInfo) {
        userInfo.innerHTML = currentUser.name + ' <a class="logout-link" id="logoutBtn">退出</a>';
        document.getElementById('logoutBtn').addEventListener('click', doLogout);
    }

    if (currentUser.role === 'guest') {
        document.querySelectorAll('.nav-item').forEach(nav => {
            if (nav.dataset.page === 'page-system') {
                nav.style.display = 'none';
            }
        });
        document.body.setAttribute('data-role', 'guest');
    } else {
        document.querySelectorAll('.nav-item').forEach(nav => {
            if (nav.dataset.page === 'page-system') {
                nav.style.display = '';
            }
        });
        document.body.removeAttribute('data-role');
    }
}

// 登录表单提交
document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    if (!username || !password) {
        document.getElementById('loginError').textContent = '请输入用户名和密码';
        return;
    }
    doLogin(username, password).then(success => {
        if (!success) {
            document.getElementById('loginError').textContent = '用户名或密码错误';
        }
    });
});

// 页面加载时检查登录状态
checkAuth();

// ==================== 时间显示 ====================
function updateTime() {
    const now = new Date();
    document.getElementById('currentTime').textContent =
        now.getFullYear() + '年' + String(now.getMonth()+1).padStart(2,'0') + '月' +
        String(now.getDate()).padStart(2,'0') + '日 ' +
        String(now.getHours()).padStart(2,'0') + ':' +
        String(now.getMinutes()).padStart(2,'0') + ':' +
        String(now.getSeconds()).padStart(2,'0');
}
updateTime(); setInterval(updateTime, 1000);

// ==================== 地图管理 ====================
const maps = {};
let forestCenter, forestBoundary, subCompartments, subColors;
let fireImageData, pestImageData, firePointData;

// 异步加载应用数据（切换后端时自动走API）
async function initAppData() {
    const config = await ApiService.getForestConfig();
    forestCenter = config.center;
    forestBoundary = config.boundary;
    subCompartments = await ApiService.getCompartments();
    subColors = await ApiService.getCompartmentColors();
    fireImageData = await ApiService.getFireRecognition();
    pestImageData = await ApiService.getPestRecognition();
    firePointData = await ApiService.getFirePoints();
}

function createMap(id) {
    if (maps[id]) { maps[id].invalidateSize(); return maps[id]; }
    const map = L.map(id, {center: forestCenter, zoom: 14, attributionControl: false, zoomControl: false});
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {maxZoom:19}).addTo(map);
    maps[id] = map;
    return map;
}

function addForestLayers(map) {
    L.polygon(forestBoundary, {color:'#ff9800',weight:2,opacity:0.8,fillColor:'#ff9800',fillOpacity:0.06,dashArray:'8,4'}).addTo(map);
    subCompartments.forEach((sc,i) => {
        L.polygon(sc.coords, {color:subColors[i],weight:1.5,opacity:0.6,fillColor:subColors[i],fillOpacity:0.08}).addTo(map).bindTooltip(sc.name);
    });
}

async function addDemoPoints(map) {
    const rIcon = L.divIcon({html:'<div style="width:12px;height:12px;background:#00e676;border:2px solid #fff;border-radius:50%;box-shadow:0 0 6px rgba(0,230,118,0.6);"></div>',className:'',iconSize:[12,12],iconAnchor:[6,6]});
    const dIcon = L.divIcon({html:'<div style="width:14px;height:14px;background:#448aff;border:2px solid #fff;border-radius:3px;box-shadow:0 0 8px rgba(68,138,255,0.6);transform:rotate(45deg);"></div>',className:'',iconSize:[14,14],iconAnchor:[7,7]});
    const fIcon = L.divIcon({html:'<div style="width:18px;height:18px;background:radial-gradient(circle,#ff6e40,#ff3d3d);border-radius:50%;box-shadow:0 0 10px rgba(255,61,61,0.8);"></div>',className:'',iconSize:[18,18],iconAnchor:[9,9]});
    const pIcon = L.divIcon({html:'<div style="width:14px;height:14px;background:radial-gradient(circle,#ffcc02,#ff9800);border-radius:50%;box-shadow:0 0 6px rgba(255,152,0,0.6);"></div>',className:'',iconSize:[14,14],iconAnchor:[7,7]});

    const rangers = await ApiService.getRangers();
    rangers.forEach(r => {
        L.marker([r.lat,r.lng],{icon:rIcon}).addTo(map)
            .bindTooltip(r.name)
            .bindPopup(`<div class="popup-info"><div class="popup-title" style="color:#00e676;">护林员</div><div class="popup-row"><span class="popup-label">姓名</span><span class="popup-val">${r.name}</span></div><div class="popup-row"><span class="popup-label">工号</span><span class="popup-val">${r.id}</span></div><div class="popup-row"><span class="popup-label">负责区域</span><span class="popup-val">${r.area}</span></div><div class="popup-row"><span class="popup-label">状态</span><span class="popup-val">${r.status}</span></div><div class="popup-row"><span class="popup-label">行进速度</span><span class="popup-val">${r.speed}</span></div><div class="popup-row"><span class="popup-label">设备电量</span><span class="popup-val">${r.battery}</span></div><div class="popup-row"><span class="popup-label">经度</span><span class="popup-val">${r.lng.toFixed(6)}</span></div><div class="popup-row"><span class="popup-label">纬度</span><span class="popup-val">${r.lat.toFixed(6)}</span></div></div>`);
    });

    const drones = await ApiService.getDrones();
    drones.forEach(d => {
        L.marker([d.lat,d.lng],{icon:dIcon}).addTo(map)
            .bindTooltip(d.name)
            .bindPopup(`<div class="popup-info"><div class="popup-title" style="color:#448aff;">无人机</div><div class="popup-row"><span class="popup-label">编号</span><span class="popup-val">${d.name}</span></div><div class="popup-row"><span class="popup-label">型号</span><span class="popup-val">${d.model}</span></div><div class="popup-row"><span class="popup-label">飞行高度</span><span class="popup-val">${d.alt}</span></div><div class="popup-row"><span class="popup-label">航向</span><span class="popup-val">${d.heading}</span></div><div class="popup-row"><span class="popup-label">电量</span><span class="popup-val">${d.battery}</span></div><div class="popup-row"><span class="popup-label">状态</span><span class="popup-val">${d.status}</span></div><div class="popup-row"><span class="popup-label">经度</span><span class="popup-val">${d.lng.toFixed(6)}</span></div><div class="popup-row"><span class="popup-label">纬度</span><span class="popup-val">${d.lat.toFixed(6)}</span></div></div>`);
    });

    const fires = await ApiService.getFires();
    fires.forEach(f => {
        L.marker([f.lat,f.lng],{icon:fIcon}).addTo(map)
            .bindTooltip('火情-' + f.level)
            .bindPopup(`<div class="popup-info"><div class="popup-title" style="color:#ff3d3d;">火情点</div><div class="popup-row"><span class="popup-label">编号</span><span class="popup-val">${f.name}</span></div><div class="popup-row"><span class="popup-label">等级</span><span class="popup-val">${f.level}</span></div><div class="popup-row"><span class="popup-label">位置</span><span class="popup-val">${f.area}</span></div><div class="popup-row"><span class="popup-label">发现时间</span><span class="popup-val">${f.time}</span></div><div class="popup-row"><span class="popup-label">状态</span><span class="popup-val">${f.status}</span></div><div class="popup-row"><span class="popup-label">经度</span><span class="popup-val">${f.lng.toFixed(6)}</span></div><div class="popup-row"><span class="popup-label">纬度</span><span class="popup-val">${f.lat.toFixed(6)}</span></div></div>`);
        L.circle([f.lat,f.lng],{radius:200,color:'#ff3d3d',weight:1,fillOpacity:0.1}).addTo(map);
    });

    const pests = await ApiService.getPests();
    pests.forEach((p,i) => {
        L.marker([p.lat,p.lng],{icon:pIcon}).addTo(map)
            .bindTooltip('松材线虫病')
            .bindPopup(`<div class="popup-info"><div class="popup-title" style="color:#ff9800;">松材线虫病</div><div class="popup-row"><span class="popup-label">编号</span><span class="popup-val">P${String(i+1).padStart(3,'0')}</span></div><div class="popup-row"><span class="popup-label">所在区域</span><span class="popup-val">${p.area}</span></div><div class="popup-row"><span class="popup-label">感染面积</span><span class="popup-val">${p.areaSize}</span></div><div class="popup-row"><span class="popup-label">经度</span><span class="popup-val">${p.lng.toFixed(6)}</span></div><div class="popup-row"><span class="popup-label">纬度</span><span class="popup-val">${p.lat.toFixed(6)}</span></div></div>`);
    });

    // 巡护轨迹
    const patrolRoutes = await ApiService.getPatrolRoutes();
    patrolRoutes.forEach(route => {
        L.polyline(route.coords,{color:'#00e676',weight:2,opacity:0.7,dashArray:'6,4'}).addTo(map).bindPopup(`<div class="popup-info"><div class="popup-title" style="color:#00e676;">巡护轨迹</div><div class="popup-row"><span class="popup-label">巡护人</span><span class="popup-val">${route.person}</span></div><div class="popup-row"><span class="popup-label">日期</span><span class="popup-val">${route.date}</span></div><div class="popup-row"><span class="popup-label">里程</span><span class="popup-val">${route.distance}</span></div></div>`);
    });
}

// ==================== 导航切换 ====================
const pageInited = {};
document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', function(e) {
        // 涟漪动画
        const ripple = document.createElement('span');
        ripple.style.cssText = `position:absolute;border-radius:50%;background:rgba(0,170,255,0.25);transform:scale(0);animation:navRipple 0.6s ease-out;pointer-events:none;width:120px;height:120px;left:${e.offsetX-60}px;top:${e.offsetY-60}px;`;
        this.appendChild(ripple);
        setTimeout(() => ripple.remove(), 600);

        const pageId = this.dataset.page;
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
        document.getElementById(pageId).classList.add('active');
        this.classList.add('active');
        if (!pageInited[pageId]) {
            pageInited[pageId] = true;
            if (pageId === 'page-resource') initResourcePage();
            if (pageId === 'page-spatial') initSpatialPage();
            if (pageId === 'page-disaster') initDisasterPage();
            if (pageId === 'page-report') initReportPage();
            if (pageId === 'page-system') initSystemPage();
        }
        setTimeout(() => Object.values(maps).forEach(m => m && m.invalidateSize()), 100);
    });
});

// 二级导航切换
document.addEventListener('click', function(e) {
    const subNav = e.target.closest('.sub-nav-item');
    if (subNav && subNav.dataset.sub) {
        const parent = subNav.closest('.sub-nav-bar');
        parent.querySelectorAll('.sub-nav-item').forEach(n => n.classList.remove('active'));
        subNav.classList.add('active');
        const container = parent.nextElementSibling;
        container.querySelectorAll(':scope > .sub-page').forEach(p => p.classList.remove('active'));
        document.getElementById(subNav.dataset.sub).classList.add('active');
        setTimeout(() => Object.values(maps).forEach(m => m && m.invalidateSize()), 100);
    }
    const innerTab = e.target.closest('.sub-tab-item');
    if (innerTab && innerTab.dataset.inner) {
        const parent = innerTab.closest('.sub-tab-bar');
        parent.querySelectorAll('.sub-tab-item').forEach(n => n.classList.remove('active'));
        innerTab.classList.add('active');
        const container = parent.parentElement;
        container.querySelectorAll('.inner-tab').forEach(t => t.classList.remove('active'));
        document.getElementById(innerTab.dataset.inner).classList.add('active');
    }
});

// ==================== 页面二：资源与巡护业务地图初始化 ====================
function initResourcePage() {
    setTimeout(async () => {
        const realtimeMap = createMap('resRealtimeMap');
        addForestLayers(realtimeMap);
        await addDemoPoints(realtimeMap);
        const coverageMap = createMap('resCoverageMap');
        addForestLayers(coverageMap);
        await addDemoPoints(coverageMap);
        const taskMap = createMap('resTaskMap');
        addForestLayers(taskMap);
        await addDemoPoints(taskMap);
    }, 200);
    // 空间与灾害分析子页面地图延迟初始化
    let analysisMapInited = false;
    document.querySelectorAll('#page-resource .sub-nav-item').forEach(nav => {
        nav.addEventListener('click', async function() {
            const subId = this.dataset.sub;
            if (subId === 'sub-res-analysis' && !analysisMapInited) {
                setTimeout(async () => {
                    const m = createMap('resAnalysisMap');
                    addForestLayers(m);
                    await addDemoPoints(m);
                    analysisMapInited = true;
                }, 300);
            }
            setTimeout(() => Object.values(maps).forEach(m => m && m.invalidateSize()), 350);
        });
    });
}

// ==================== 驾驶舱地图初始化 ====================
let dashMap;
initAppData().then(async () => {
    dashMap = createMap('dashMap');
    addForestLayers(dashMap);
    await addDemoPoints(dashMap);
});

// ==================== 驾驶舱侧边栏（左右独立） ====================
// 左侧边栏 - 图层管理
document.getElementById('layerToggle').addEventListener('click', function() {
    const sidebar = document.getElementById('layerSidebar');
    const isOpen = sidebar.classList.toggle('open');
    this.classList.toggle('active', isOpen);
    setTimeout(() => dashMap && dashMap.invalidateSize(), 350);
});
document.getElementById('layerClose').addEventListener('click', function() {
    document.getElementById('layerSidebar').classList.remove('open');
    document.getElementById('layerToggle').classList.remove('active');
    setTimeout(() => dashMap && dashMap.invalidateSize(), 350);
});
// 右侧边栏 - 林场编辑
document.getElementById('editToggle').addEventListener('click', function() {
    const sidebar = document.getElementById('editSidebar');
    const isOpen = sidebar.classList.toggle('open');
    this.classList.toggle('active', isOpen);
    setTimeout(() => dashMap && dashMap.invalidateSize(), 350);
});
document.getElementById('editClose').addEventListener('click', function() {
    document.getElementById('editSidebar').classList.remove('open');
    document.getElementById('editToggle').classList.remove('active');
    setTimeout(() => dashMap && dashMap.invalidateSize(), 350);
});

// ==================== 页面三：空间分析 ====================
function initSpatialPage() {
    document.getElementById('page-spatial').innerHTML = `
    <div class="sub-tab-bar">
        <a class="sub-tab-item active" data-inner="inner-fire-analysis">火情分析</a>
        <a class="sub-tab-item" data-inner="inner-epidemic">疫情分析</a>
        <a class="sub-tab-item" data-inner="inner-ndvi">NDVI分析</a>
        <a class="sub-tab-item" data-inner="inner-landuse">土地利用分析</a>
    </div>
    <div class="content-split content-split-wide">
        <div class="content-left-map content-map-wide"><div id="monSpatialMap"></div></div>
        <div class="content-right-panel content-panel-narrow">
            <div class="inner-tab active" id="inner-fire-analysis">
                <div class="panel-card"><div class="card-header"><h3>火情分析</h3></div><div class="card-body">
                    <div class="form-group"><label>分析区域</label><select class="select-full"><option>全部林区</option><option>一号林区</option><option>二号林区</option><option>三号林区</option><option>四号林区</option><option>五号林区</option></select></div>
                    <div class="form-group"><label>蔓延预测时间</label><select class="select-full"><option>20分钟</option><option>1小时</option><option>2小时</option><option>4小时</option><option>6小时</option><option>12小时</option><option>24小时</option></select></div>
                    <div class="form-group"><label>风向风速</label><div class="form-row"><div class="form-group half"><select class="select-full"><option>东北风</option><option>北风</option><option>东风</option><option>东南风</option><option>南风</option><option>西南风</option><option>西风</option><option>西北风</option></select></div><div class="form-group half"><select class="select-full"><option>1级 (0.3-1.5m/s)</option><option>2级 (1.6-3.3m/s)</option><option>3级 (3.4-5.4m/s)</option><option>4级 (5.5-7.9m/s)</option><option>5级 (8.0-10.7m/s)</option><option>6级 (10.8-13.8m/s)</option></select></div></div></div>
                    <button class="btn btn-primary btn-block">执行分析</button>
                    <div class="analysis-result" style="margin-top:14px;"><div class="result-item"><span class="result-label">火点</span><span class="result-value red">3 处</span></div><div class="result-item"><span class="result-label">蔓延方向</span><span class="result-value orange">西南方向</span></div><div class="result-item"><span class="result-label">蔓延速度</span><span class="result-value orange">1.2 km/h</span></div><div class="result-item"><span class="result-label">影响面积预估</span><span class="result-value red">86 亩</span></div></div>
                    <div class="blind-area-list" style="margin-top:10px;"><h4>火点</h4><div class="blind-item"><span>F001 三号林区 · 较大</span><span class="tag tag-red tag-sm">蔓延中</span><button class="btn btn-sm btn-outline" style="margin-left:auto;font-size:11px;padding:2px 8px;" onclick="viewFirePoint('F001')">查看处置</button></div><div class="blind-item"><span>F002 一号林区 · 一般</span><span class="tag tag-orange tag-sm">控制中</span><button class="btn btn-sm btn-outline" style="margin-left:auto;font-size:11px;padding:2px 8px;" onclick="viewFirePoint('F002')">查看处置</button></div><div class="blind-item"><span>F003 四号林区 · 一般</span><span class="tag tag-blue tag-sm">已派发</span><button class="btn btn-sm btn-outline" style="margin-left:auto;font-size:11px;padding:2px 8px;" onclick="viewFirePoint('F003')">查看处置</button></div></div>
                </div></div>
            </div>
            <div class="inner-tab" id="inner-epidemic">
                <div class="panel-card"><div class="card-header"><h3>疫情分析</h3></div><div class="card-body">
                    <div class="form-group"><label>疫病类型</label><select class="select-full"><option>松材线虫病</option><option>美国白蛾</option><option>杨树病害</option><option>其他林业疫病</option></select></div>
                    <div class="form-group"><label>分析区域</label><select class="select-full"><option>全部林区</option><option>一号林区</option><option>二号林区</option><option>三号林区</option><option>四号林区</option><option>五号林区</option></select></div>
                    <div class="form-group"><label>时间范围</label><select class="select-full"><option>近30天</option><option>近90天</option><option>近半年</option><option>近一年</option></select></div>
                    <button class="btn btn-primary btn-block">执行分析</button>
                    <div class="analysis-result" style="margin-top:14px;"><div class="result-item"><span class="result-label">感染总面积</span><span class="result-value red">38.2 亩</span></div><div class="result-item"><span class="result-label">感染点数量</span><span class="result-value orange">7 处</span></div><div class="result-item"><span class="result-label">扩散趋势</span><span class="result-value orange">缓慢扩散</span></div><div class="result-item"><span class="result-label">风险等级</span><span class="result-value orange">中等</span></div></div>
                    <div class="blind-area-list" style="margin-top:10px;"><h4>疫点分布</h4><div class="blind-item"><span>一号林区 P001 5.2亩</span><span class="tag tag-red tag-sm">活跃</span></div><div class="blind-item"><span>二号林区 P002 3.8亩</span><span class="tag tag-orange tag-sm">处置中</span></div><div class="blind-item"><span>三号林区 P003 8.1亩</span><span class="tag tag-green tag-sm">已控制</span></div></div>
                </div></div>
            </div>
            <div class="inner-tab" id="inner-ndvi">
                <div class="panel-card"><div class="card-header"><h3>NDVI归一化植被指数分析</h3></div><div class="card-body">
                    <div class="form-group"><label>数据源</label><select class="select-full"><option>Sentinel-2 卫星影像</option><option>Landsat-8 卫星影像</option><option>GF-1 卫星影像</option><option>无人机多光谱</option></select></div>
                    <div class="form-group"><label>分析区域</label><select class="select-full"><option>全部林区</option><option>一号林区</option><option>二号林区</option><option>三号林区</option><option>四号林区</option><option>五号林区</option></select></div>
                    <div class="form-row"><div class="form-group half"><label>起始日期</label><input type="date" value="2026-05-01"/></div><div class="form-group half"><label>结束日期</label><input type="date" value="2026-06-10"/></div></div>
                    <button class="btn btn-primary btn-block">加载并分析</button>
                    <div class="analysis-result" style="margin-top:14px;"><div class="result-item"><span class="result-label">平均NDVI</span><span class="result-value green">0.72</span></div><div class="result-item"><span class="result-label">植被覆盖度</span><span class="result-value blue">82.3%</span></div><div class="result-item"><span class="result-label">退化区域</span><span class="result-value red">4 处</span></div><div class="result-item"><span class="result-label">改善区域</span><span class="result-value green">2 处</span></div></div>
                    <div class="blind-area-list" style="margin-top:10px;"><h4>异常区域列表</h4><div class="blind-item"><span>一号林区东南部 NDVI=0.31</span><span class="tag tag-red tag-sm">严重退化</span></div><div class="blind-item"><span>三号林区西北角 NDVI=0.38</span><span class="tag tag-orange tag-sm">中度退化</span></div><div class="blind-item"><span>五号林区中部 NDVI=0.42</span><span class="tag tag-orange tag-sm">轻度退化</span></div></div>
                </div></div>
            </div>
            <div class="inner-tab" id="inner-landuse">
                <div class="panel-card"><div class="card-header"><h3>土地利用分析</h3></div><div class="card-body">
                    <div class="form-group"><label>分类体系</label><select class="select-full"><option>国家标准分类（GB/T 21010）</option><option>森林资源分类</option><option>自定义分类</option></select></div>
                    <div class="form-group"><label>分析区域</label><select class="select-full"><option>全部林区</option><option>一号林区</option><option>二号林区</option><option>三号林区</option><option>四号林区</option><option>五号林区</option></select></div>
                    <div class="form-group"><label>对比期</label><select class="select-full"><option>2026年 vs 2025年</option><option>2026年 vs 2023年</option><option>2026年 vs 2020年</option></select></div>
                    <button class="btn btn-primary btn-block">执行分析</button>
                    <div class="analysis-result" style="margin-top:14px;"><div class="result-item"><span class="result-label">有林地</span><span class="result-value green">9,820 亩</span></div><div class="result-item"><span class="result-label">灌木林地</span><span class="result-value blue">1,560 亩</span></div><div class="result-item"><span class="result-label">疏林地</span><span class="result-value orange">680 亩</span></div><div class="result-item"><span class="result-label">变化面积</span><span class="result-value red">-120 亩</span></div></div>
                    <div class="blind-area-list" style="margin-top:10px;"><h4>地类变化明细</h4><div class="blind-item"><span>二号林区：疏林地→有林地</span><span class="tag tag-green tag-sm">+85亩</span></div><div class="blind-item"><span>四号林区：有林地→灌木林地</span><span class="tag tag-red tag-sm">-205亩</span></div></div>
                </div></div>
            </div>
        </div>
    </div>`;
    setTimeout(async () => {
        const m = createMap('monSpatialMap'); addForestLayers(m); await addDemoPoints(m);
        Object.values(maps).forEach(m => m && m.invalidateSize());
    }, 300);
}

function initDisasterPage() {
    document.getElementById('page-disaster').innerHTML = `
    <div class="sub-tab-bar">
        <a class="sub-tab-item active" data-inner="inner-fire-identify">火情识别</a>
        <a class="sub-tab-item" data-inner="inner-pest-identify">疫情识别</a>
        <a class="sub-tab-item" data-inner="inner-abnormal-mgmt">异常事件</a>
        <a class="sub-tab-item" data-inner="inner-risk-warning">综合风险预警</a>
    </div>
    <div class="content-full-panel">
        <div class="inner-tab active" id="inner-fire-identify">
            <div class="panel-card"><div class="card-header"><h3>火情AI识别</h3><div class="card-actions"><button class="btn btn-primary">上传图像</button><button class="btn btn-outline">无人机图像导入</button><button class="btn btn-outline" onclick="runFireIdentify()">执行AI识别</button></div></div><div class="card-body">
                <div class="identify-toolbar" style="display:flex;gap:8px;margin-bottom:14px;align-items:center;">
                    <span style="color:#8899aa;font-size:12px;">图像来源：</span>
                    <select class="select-full" style="max-width:160px;"><option>全部</option><option>无人机拍摄</option><option>人工拍摄</option></select>
                    <span style="color:#8899aa;font-size:12px;margin-left:12px;">识别状态：</span>
                    <select class="select-full" style="max-width:140px;"><option>全部</option><option>高危</option><option>疑似</option><option>正常</option></select>
                </div>
                <div class="identify-gallery" id="fireGallery" style="display:grid;grid-template-columns:repeat(5,1fr);gap:10px;">
                </div>
                <div style="margin-top:12px;display:flex;justify-content:center;gap:8px;">
                    <button class="btn btn-sm btn-outline" onclick="switchFirePage('prev')">上一页</button>
                    <span id="firePageInfo" style="color:#8899aa;font-size:12px;line-height:30px;">第 1 / 3 页</span>
                    <button class="btn btn-sm btn-outline" onclick="switchFirePage('next')">下一页</button>
                </div>
            </div></div>
        </div>
        <div class="inner-tab" id="inner-pest-identify">
            <div class="panel-card"><div class="card-header"><h3>疫情AI识别</h3><div class="card-actions"><button class="btn btn-primary">上传图像</button><button class="btn btn-outline">无人机图像导入</button><button class="btn btn-outline" onclick="runPestIdentify()">执行AI识别</button></div></div><div class="card-body">
                <div class="identify-toolbar" style="display:flex;gap:8px;margin-bottom:14px;align-items:center;">
                    <span style="color:#8899aa;font-size:12px;">图像来源：</span>
                    <select class="select-full" style="max-width:160px;"><option>全部</option><option>无人机拍摄</option><option>人工拍摄</option></select>
                    <span style="color:#8899aa;font-size:12px;margin-left:12px;">识别状态：</span>
                    <select class="select-full" style="max-width:140px;"><option>全部</option><option>高危</option><option>疑似</option><option>正常</option></select>
                </div>
                <div class="identify-gallery" id="pestGallery" style="display:grid;grid-template-columns:repeat(5,1fr);gap:10px;">
                </div>
                <div style="margin-top:12px;display:flex;justify-content:center;gap:8px;">
                    <button class="btn btn-sm btn-outline" onclick="switchPestPage('prev')">上一页</button>
                    <span id="pestPageInfo" style="color:#8899aa;font-size:12px;line-height:30px;">第 1 / 2 页</span>
                    <button class="btn btn-sm btn-outline" onclick="switchPestPage('next')">下一页</button>
                </div>
            </div></div>
        </div>
        <div class="inner-tab" id="inner-abnormal-mgmt"><div class="panel-card"><div class="card-header"><h3>异常事件</h3><div class="card-actions"><button class="btn btn-primary">上报事件</button></div></div><div class="card-body"><div class="event-type-filter"><button class="btn btn-sm btn-outline active">全部</button><button class="btn btn-sm btn-outline">盗伐</button><button class="btn btn-sm btn-outline">非法占地</button><button class="btn btn-sm btn-outline">垃圾倾倒</button><button class="btn btn-sm btn-outline">违规用火</button></div><table class="data-table"><thead><tr><th>编号</th><th>类型</th><th>位置</th><th>上报人</th><th>状态</th><th>操作</th></tr></thead><tbody><tr><td>E001</td><td>违规用火</td><td>一号林区南侧</td><td>张建国</td><td><span class="tag tag-orange">处理中</span></td><td><a class="link-btn">定位</a><a class="link-btn">处理</a></td></tr><tr><td>E002</td><td>盗伐</td><td>四号林区西侧</td><td>UAV-03</td><td><span class="tag tag-blue">已派发</span></td><td><a class="link-btn">定位</a><a class="link-btn">处理</a></td></tr></tbody></table></div></div></div>
        <div class="inner-tab" id="inner-risk-warning">
            <div class="panel-card"><div class="card-header"><h3>综合风险预警</h3><div class="card-actions"><button class="btn btn-primary" onclick="runRiskAssessment()">执行风险评估</button><button class="btn btn-outline" onclick="exportRiskReport()">导出评估报告</button></div></div><div class="card-body">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                    <div class="panel-card" style="margin:0;"><div class="card-header"><h3>评估参数配置</h3></div><div class="card-body">
                        <div class="form-group"><label>评估区域</label><select class="select-full"><option>全部林区</option><option>一号林区</option><option>二号林区</option><option>三号林区</option><option>四号林区</option><option>五号林区</option></select></div>
                        <div class="form-group"><label>灾害类型</label><select class="select-full"><option>综合评估</option><option>森林火灾</option><option>林业有害生物</option><option>气象灾害</option><option>地质灾害</option></select></div>
                        <div class="form-group"><label>评估时间范围</label><div class="form-row"><div class="form-group half"><input type="date" value="2026-06-01"/></div><div class="form-group half"><input type="date" value="2026-06-10"/></div></div></div>
                        <div class="form-group"><label>气象权重</label><div style="display:flex;align-items:center;gap:8px;"><input type="range" min="0" max="100" value="30" style="flex:1;accent-color:var(--accent-blue);"/><span style="color:var(--text-secondary);font-size:12px;min-width:32px;">30%</span></div></div>
                        <div class="form-group"><label>地形权重</label><div style="display:flex;align-items:center;gap:8px;"><input type="range" min="0" max="100" value="25" style="flex:1;accent-color:var(--accent-blue);"/><span style="color:var(--text-secondary);font-size:12px;min-width:32px;">25%</span></div></div>
                        <div class="form-group"><label>植被权重</label><div style="display:flex;align-items:center;gap:8px;"><input type="range" min="0" max="100" value="25" style="flex:1;accent-color:var(--accent-blue);"/><span style="color:var(--text-secondary);font-size:12px;min-width:32px;">25%</span></div></div>
                        <div class="form-group"><label>人为活动权重</label><div style="display:flex;align-items:center;gap:8px;"><input type="range" min="0" max="100" value="20" style="flex:1;accent-color:var(--accent-blue);"/><span style="color:var(--text-secondary);font-size:12px;min-width:32px;">20%</span></div></div>
                        <div class="form-group"><label>预警阈值</label><select class="select-full"><option>中风险（60分）</option><option>低风险（40分）</option><option>高风险（80分）</option></select></div>
                    </div></div>
                    <div class="panel-card" style="margin:0;"><div class="card-header"><h3>风险等级概览</h3></div><div class="card-body">
                        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px;">
                            <div style="text-align:center;padding:12px 8px;border-radius:6px;background:rgba(255,61,61,0.1);border:1px solid rgba(255,61,61,0.2);"><div style="font-size:24px;font-weight:700;color:#ff3d3d;">2</div><div style="font-size:11px;color:#ff3d3d;margin-top:4px;">极高风险</div></div>
                            <div style="text-align:center;padding:12px 8px;border-radius:6px;background:rgba(255,152,0,0.1);border:1px solid rgba(255,152,0,0.2);"><div style="font-size:24px;font-weight:700;color:#ff9800;">3</div><div style="font-size:11px;color:#ff9800;margin-top:4px;">高风险</div></div>
                            <div style="text-align:center;padding:12px 8px;border-radius:6px;background:rgba(255,193,7,0.1);border:1px solid rgba(255,193,7,0.2);"><div style="font-size:24px;font-weight:700;color:#ffc107;">5</div><div style="font-size:11px;color:#ffc107;margin-top:4px;">中风险</div></div>
                            <div style="text-align:center;padding:12px 8px;border-radius:6px;background:rgba(76,175,80,0.1);border:1px solid rgba(76,175,80,0.2);"><div style="font-size:24px;font-weight:700;color:#4caf50;">8</div><div style="font-size:11px;color:#4caf50;margin-top:4px;">低风险</div></div>
                        </div>
                        <div style="margin-bottom:12px;"><h4 style="font-size:12px;color:var(--text-secondary);margin-bottom:8px;">各林区风险评分</h4>
                            <div style="margin-bottom:8px;"><div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px;"><span>一号林区</span><span style="color:#ff3d3d;font-weight:600;">82分</span></div><div style="height:6px;background:rgba(255,255,255,0.06);border-radius:3px;overflow:hidden;"><div style="width:82%;height:100%;background:linear-gradient(90deg,#ff9800,#ff3d3d);border-radius:3px;"></div></div></div>
                            <div style="margin-bottom:8px;"><div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px;"><span>二号林区</span><span style="color:#ff9800;font-weight:600;">67分</span></div><div style="height:6px;background:rgba(255,255,255,0.06);border-radius:3px;overflow:hidden;"><div style="width:67%;height:100%;background:linear-gradient(90deg,#ffc107,#ff9800);border-radius:3px;"></div></div></div>
                            <div style="margin-bottom:8px;"><div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px;"><span>三号林区</span><span style="color:#ff3d3d;font-weight:600;">91分</span></div><div style="height:6px;background:rgba(255,255,255,0.06);border-radius:3px;overflow:hidden;"><div style="width:91%;height:100%;background:linear-gradient(90deg,#ff3d3d,#d32f2f);border-radius:3px;"></div></div></div>
                            <div style="margin-bottom:8px;"><div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px;"><span>四号林区</span><span style="color:#ffc107;font-weight:600;">54分</span></div><div style="height:6px;background:rgba(255,255,255,0.06);border-radius:3px;overflow:hidden;"><div style="width:54%;height:100%;background:linear-gradient(90deg,#4caf50,#ffc107);border-radius:3px;"></div></div></div>
                            <div style="margin-bottom:8px;"><div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:3px;"><span>五号林区</span><span style="color:#4caf50;font-weight:600;">38分</span></div><div style="height:6px;background:rgba(255,255,255,0.06);border-radius:3px;overflow:hidden;"><div style="width:38%;height:100%;background:linear-gradient(90deg,#4caf50,#66bb6a);border-radius:3px;"></div></div></div>
                        </div>
                    </div></div>
                </div>
                <div class="panel-card" style="margin-top:16px;"><div class="card-header"><h3>风险事件列表</h3><div class="card-actions"><button class="btn btn-sm btn-outline">全部</button><button class="btn btn-sm btn-outline">极高风险</button><button class="btn btn-sm btn-outline">高风险</button><button class="btn btn-sm btn-outline">中风险</button></div></div><div class="card-body">
                    <table class="data-table"><thead><tr><th>编号</th><th>风险类型</th><th>关联区域</th><th>风险评分</th><th>风险等级</th><th>主要致险因子</th><th>更新时间</th><th>操作</th></tr></thead><tbody>
                        <tr><td>RW001</td><td>森林火灾</td><td>三号林区</td><td><span style="color:#ff3d3d;font-weight:700;">91</span></td><td><span class="tag tag-red">极高风险</span></td><td>持续高温干旱 + 可燃物载量大</td><td>2026-06-10 08:30</td><td><a class="link-btn">详情</a><a class="link-btn">处置</a></td></tr>
                        <tr><td>RW002</td><td>森林火灾</td><td>一号林区</td><td><span style="color:#ff3d3d;font-weight:700;">82</span></td><td><span class="tag tag-red">极高风险</span></td><td>雷击火险 + 风力较大</td><td>2026-06-10 07:15</td><td><a class="link-btn">详情</a><a class="link-btn">处置</a></td></tr>
                        <tr><td>RW003</td><td>林业有害生物</td><td>二号林区</td><td><span style="color:#ff9800;font-weight:700;">67</span></td><td><span class="tag tag-orange">高风险</span></td><td>松材线虫扩散 + 防治滞后</td><td>2026-06-09 16:45</td><td><a class="link-btn">详情</a><a class="link-btn">处置</a></td></tr>
                        <tr><td>RW004</td><td>气象灾害</td><td>一号林区</td><td><span style="color:#ff9800;font-weight:700;">63</span></td><td><span class="tag tag-orange">高风险</span></td><td>暴雨预警 + 低洼地形</td><td>2026-06-09 14:20</td><td><a class="link-btn">详情</a><a class="link-btn">处置</a></td></tr>
                        <tr><td>RW005</td><td>地质灾害</td><td>四号林区</td><td><span style="color:#ff9800;font-weight:700;">58</span></td><td><span class="tag tag-orange">高风险</span></td><td>坡度>35° + 土壤含水饱和</td><td>2026-06-09 11:00</td><td><a class="link-btn">详情</a><a class="link-btn">处置</a></td></tr>
                        <tr><td>RW006</td><td>林业有害生物</td><td>四号林区</td><td><span style="color:#ffc107;font-weight:700;">54</span></td><td><span class="tag tag-yellow" style="background:rgba(255,193,7,0.15);color:#ffc107;border:1px solid rgba(255,193,7,0.3);padding:2px 8px;border-radius:10px;font-size:11px;">中风险</span></td><td>美国白蛾监测阳性</td><td>2026-06-08 09:30</td><td><a class="link-btn">详情</a><a class="link-btn">处置</a></td></tr>
                    </tbody></table>
                </div></div>
            </div></div>
        </div>
    </div>`;
}

// ==================== 图像识别交互函数 ====================
// fireImageData, pestImageData 已在 initAppData() 中异步加载

function generateFireSVG(type, idx) {
    const uid = 'fs' + idx;
    const confidences = [92.3, 87.5, 78.1, 95.6, 83.2, 71.4, 96.8, 79.3, 88.9, 74.5, 91.7, 85.3, 77.8, 93.1, 82.6, 90.4];
    const conf = confidences[idx % confidences.length];
    const barW = Math.round(conf * 0.4);
    const barColor = conf >= 90 ? '#ff3d3d' : conf >= 80 ? '#ff9800' : '#4fc3f7';

    if (type === 'fire') {
        const cx = 60 + (idx * 17) % 80;
        const bx = cx - 30, by = 60, bw = 60, bh = 55;
        return `<svg viewBox="0 0 200 140" style="width:100%;display:block;background:#1a1a2e;"><defs><radialGradient id="${uid}" cx="${cx}%" cy="75%" r="38%"><stop offset="0%" stop-color="#ffeb3b"/><stop offset="25%" stop-color="#ff6e40"/><stop offset="65%" stop-color="#ff3d3d"/><stop offset="100%" stop-color="transparent"/></radialGradient></defs><rect width="200" height="140" fill="#1a1a2e"/><polygon points="0,140 ${20+idx*3},90 ${50+idx*2},115 ${80+idx},70 ${110+idx*2},100 ${140+idx},60 ${170+idx*2},95 200,80 200,140" fill="#0d3d0d" opacity="0.8"/><ellipse cx="${cx}" cy="100" rx="55" ry="32" fill="url(#${uid})"/><ellipse cx="${cx-15}" cy="90" rx="12" ry="22" fill="#ffab40" opacity="0.8"/><ellipse cx="${cx+10}" cy="88" rx="10" ry="18" fill="#ff6e40" opacity="0.9"/><ellipse cx="${cx-5}" cy="82" rx="7" ry="13" fill="#ffeb3b" opacity="0.7"/><rect x="${bx}" y="${by}" width="${bw}" height="${bh}" fill="none" stroke="#ff3d3d" stroke-width="1.5" stroke-dasharray="4,2" rx="2"/><circle cx="${bx}" cy="${by}" r="3" fill="#ff3d3d"/><text x="${bx+4}" y="${by-4}" fill="#ff3d3d" font-size="8" font-weight="bold">明火 ${conf}%</text><line x1="${cx}" y1="${by+bh}" x2="${cx}" y2="${by+bh+10}" stroke="#ff3d3d" stroke-width="0.8"/><line x1="${cx-8}" y1="${by+bh+10}" x2="${cx+8}" y2="${by+bh+10}" stroke="#ff3d3d" stroke-width="0.8"/><text x="${cx-8}" y="${by+bh+18}" fill="#ffab40" font-size="6">火源中心</text><rect x="2" y="2" width="50" height="16" rx="2" fill="rgba(0,0,0,0.6)"/><rect x="4" y="6" width="${barW}" height="3" rx="1" fill="${barColor}"/><rect x="4" y="11" width="${Math.round((conf-10)*0.4)}" height="3" rx="1" fill="${barColor}" opacity="0.5"/><text x="56" y="13" fill="#e0e6ed" font-size="7">AI ${conf}%</text></svg>`;
    } else if (type === 'smoke') {
        const sx = 85 + (idx * 7) % 30;
        return `<svg viewBox="0 0 200 140" style="width:100%;display:block;background:#1a1a2e;"><rect width="200" height="140" fill="#1a2a1a"/><polygon points="0,140 25,95 55,115 85,80 115,105 145,70 175,95 200,85 200,140" fill="#1a4d1a" opacity="0.8"/><ellipse cx="100" cy="90" rx="35" ry="18" fill="#888" opacity="0.3"/><ellipse cx="95" cy="85" rx="25" ry="12" fill="#999" opacity="0.2"/><ellipse cx="105" cy="80" rx="18" ry="8" fill="#aaa" opacity="0.15"/><rect x="${sx-20}" y="68" width="50" height="35" fill="none" stroke="#ff9800" stroke-width="1.5" stroke-dasharray="4,2" rx="2"/><circle cx="${sx-20}" cy="68" r="3" fill="#ff9800"/><text x="${sx-16}" y="64" fill="#ff9800" font-size="8" font-weight="bold">烟雾 ${conf}%</text><line x1="${sx+5}" y1="68" x2="${sx+5}" y2="58" stroke="#ff9800" stroke-width="0.8"/><text x="${sx-5}" y="55" fill="#ffab40" font-size="6">烟雾扩散区</text><rect x="2" y="2" width="50" height="16" rx="2" fill="rgba(0,0,0,0.6)"/><rect x="4" y="6" width="${barW}" height="3" rx="1" fill="${barColor}"/><rect x="4" y="11" width="${Math.round((conf-10)*0.4)}" height="3" rx="1" fill="${barColor}" opacity="0.5"/><text x="56" y="13" fill="#e0e6ed" font-size="7">AI ${conf}%</text></svg>`;
    } else {
        return `<svg viewBox="0 0 200 140" style="width:100%;display:block;background:#1a1a2e;"><rect width="200" height="140" fill="#1a2a1a"/><polygon points="0,140 20,100 50,115 80,85 110,105 140,75 170,100 200,88 200,140" fill="#1a5d1a" opacity="0.8"/><rect x="60" y="55" width="70" height="50" fill="none" stroke="#4fc3f7" stroke-width="1" stroke-dasharray="4,2" rx="2"/><circle cx="60" cy="55" r="2.5" fill="#4fc3f7"/><text x="64" y="52" fill="#4fc3f7" font-size="7">巡护区域</text><rect x="2" y="2" width="50" height="16" rx="2" fill="rgba(0,0,0,0.6)"/><rect x="4" y="6" width="${barW}" height="3" rx="1" fill="#4fc3f7"/><rect x="4" y="11" width="${Math.round((conf-10)*0.4)}" height="3" rx="1" fill="#4fc3f7" opacity="0.5"/><text x="56" y="13" fill="#e0e6ed" font-size="7">AI ${conf}%</text></svg>`;
    }
}

function generatePestSVG(type, idx) {
    const uid = 'ps' + idx;
    const confidences = [89.7, 94.2, 76.3, 91.8, 85.6, 73.9, 93.4, 80.1, 88.5, 75.2, 90.6, 84.3, 77.9, 92.5, 81.7, 87.1];
    const conf = confidences[idx % confidences.length];
    const barW = Math.round(conf * 0.4);
    const barColor = conf >= 90 ? '#ff3d3d' : conf >= 80 ? '#ff9800' : '#4fc3f7';

    if (type === 'dead') {
        const tx = 80 + (idx * 13) % 40;
        return `<svg viewBox="0 0 200 140" style="width:100%;display:block;background:#1a1a2e;"><rect width="200" height="140" fill="#1a2a1a"/><polygon points="0,140 30,60 50,70 70,40 90,55 110,35 130,50 150,30 170,55 200,45 200,140" fill="#2d5d1a" opacity="0.6"/><polygon points="${tx-20},140 ${tx-10},55 ${tx},65 ${tx+5},40 ${tx+15},55 ${tx+25},35 ${tx+35},50 ${tx+45},140" fill="#8d6e2d" opacity="0.9"/><rect x="${tx+5}" y="58" width="3" height="82" fill="#5d4037"/><circle cx="${tx-5}" cy="45" r="12" fill="#6d4c2d" opacity="0.8"/><circle cx="${tx+15}" cy="38" r="10" fill="#7d5c3d" opacity="0.7"/><circle cx="${tx+5}" cy="50" r="8" fill="#5d3c1d" opacity="0.6"/><rect x="${tx-22}" y="28" width="55" height="55" fill="none" stroke="#ff3d3d" stroke-width="1.5" stroke-dasharray="4,2" rx="2"/><circle cx="${tx-22}" cy="28" r="3" fill="#ff3d3d"/><text x="${tx-18}" y="24" fill="#ff3d3d" font-size="7" font-weight="bold">枯死 ${conf}%</text><line x1="${tx+5}" y1="28" x2="${tx+5}" y2="18" stroke="#ff3d3d" stroke-width="0.8"/><text x="${tx-5}" y="15" fill="#ffab40" font-size="5.5">松材线虫病</text><rect x="2" y="2" width="50" height="16" rx="2" fill="rgba(0,0,0,0.6)"/><rect x="4" y="6" width="${barW}" height="3" rx="1" fill="${barColor}"/><rect x="4" y="11" width="${Math.round((conf-10)*0.4)}" height="3" rx="1" fill="${barColor}" opacity="0.5"/><text x="56" y="13" fill="#e0e6ed" font-size="7">AI ${conf}%</text></svg>`;
    } else if (type === 'sick') {
        const tx = 85 + (idx * 11) % 30;
        return `<svg viewBox="0 0 200 140" style="width:100%;display:block;background:#1a1a2e;"><rect width="200" height="140" fill="#1a2a1a"/><polygon points="0,140 30,65 55,75 75,50 95,60 115,45 135,55 155,40 175,60 200,50 200,140" fill="#2d6d2a" opacity="0.7"/><polygon points="${tx-10},140 ${tx},55 ${tx+10},65 ${tx+15},50 ${tx+20},60 ${tx+25},45 ${tx+30},55 ${tx+35},140" fill="#4d7d2a" opacity="0.7"/><rect x="${tx+15}" y="58" width="2" height="82" fill="#5d4037"/><circle cx="${tx+8}" cy="50" r="10" fill="#5d8d2a" opacity="0.6"/><circle cx="${tx+22}" cy="46" r="8" fill="#6d9d3a" opacity="0.5"/><rect x="${tx-8}" y="35" width="45" height="40" fill="none" stroke="#ff9800" stroke-width="1.5" stroke-dasharray="4,2" rx="2"/><circle cx="${tx-8}" cy="35" r="3" fill="#ff9800"/><text x="${tx-4}" y="32" fill="#ff9800" font-size="7" font-weight="bold">变色 ${conf}%</text><line x1="${tx+15}" y1="35" x2="${tx+15}" y2="25" stroke="#ff9800" stroke-width="0.8"/><text x="${tx+5}" y="22" fill="#ffab40" font-size="5.5">疑似感染</text><rect x="2" y="2" width="50" height="16" rx="2" fill="rgba(0,0,0,0.6)"/><rect x="4" y="6" width="${barW}" height="3" rx="1" fill="${barColor}"/><rect x="4" y="11" width="${Math.round((conf-10)*0.4)}" height="3" rx="1" fill="${barColor}" opacity="0.5"/><text x="56" y="13" fill="#e0e6ed" font-size="7">AI ${conf}%</text></svg>`;
    } else {
        return `<svg viewBox="0 0 200 140" style="width:100%;display:block;background:#1a1a2e;"><rect width="200" height="140" fill="#1a2a1a"/><polygon points="0,140 20,70 45,80 65,55 85,68 105,50 125,62 145,45 165,65 200,55 200,140" fill="#1d6d1d" opacity="0.8"/><rect x="55" y="50" width="70" height="45" fill="none" stroke="#4fc3f7" stroke-width="1" stroke-dasharray="4,2" rx="2"/><circle cx="55" cy="50" r="2.5" fill="#4fc3f7"/><text x="59" y="47" fill="#4fc3f7" font-size="7">巡护区域</text><rect x="2" y="2" width="50" height="16" rx="2" fill="rgba(0,0,0,0.6)"/><rect x="4" y="6" width="${barW}" height="3" rx="1" fill="#4fc3f7"/><rect x="4" y="11" width="${Math.round((conf-10)*0.4)}" height="3" rx="1" fill="#4fc3f7" opacity="0.5"/><text x="56" y="13" fill="#e0e6ed" font-size="7">AI ${conf}%</text></svg>`;
    }
}

const PER_PAGE = 10;
let fireCurrentPage = 1;
let pestCurrentPage = 1;

function renderGallery(galleryId, data, page, svgGenerator) {
    const gallery = document.getElementById(galleryId);
    if (!gallery) return;
    const totalPages = Math.ceil(data.length / PER_PAGE);
    const start = (page - 1) * PER_PAGE;
    const pageData = data.slice(start, start + PER_PAGE);
    gallery.innerHTML = pageData.map((item, i) => {
        const isHigh = item.level === 'high';
        const isMid = item.level === 'mid';
        const borderStyle = isHigh ? 'border:2px solid #ff3d3d;' : 'border:1px solid #2a3a4a;';
        const tagBg = isHigh ? 'rgba(255,61,61,0.9)' : isMid ? 'rgba(255,152,0,0.9)' : 'rgba(0,230,118,0.9)';
        const tagText = isHigh ? '高危' : isMid ? '疑似' : '正常';
        const svg = svgGenerator(item.svgType, start + i);
        return `<div class="identify-card${isHigh ? ' high-risk' : ''}" onclick="showImageInfo(this)" data-lat="${item.lat}" data-lng="${item.lng}" data-source="${item.source}" data-time="${item.time}" data-result="${item.result}" style="position:relative;border-radius:8px;overflow:hidden;${borderStyle}cursor:pointer;">
            ${svg}
            <div style="position:absolute;top:6px;left:6px;background:${tagBg};color:#fff;padding:2px 8px;border-radius:3px;font-size:11px;font-weight:600;">${tagText}</div>
            <div style="padding:6px 8px;background:#1a2332;"><div style="font-size:11px;color:#e0e6ed;">${item.label}</div><div style="font-size:10px;color:#8899aa;">${item.source.split('·')[0]} · ${item.time}</div></div>
        </div>`;
    }).join('');
    return totalPages;
}

function switchFirePage(dir) {
    const totalPages = Math.ceil(fireImageData.length / PER_PAGE);
    if (dir === 'next' && fireCurrentPage < totalPages) fireCurrentPage++;
    else if (dir === 'prev' && fireCurrentPage > 1) fireCurrentPage--;
    const tp = renderGallery('fireGallery', fireImageData, fireCurrentPage, generateFireSVG);
    const info = document.getElementById('firePageInfo');
    if (info) info.textContent = `第 ${fireCurrentPage} / ${tp} 页`;
}

function switchPestPage(dir) {
    const totalPages = Math.ceil(pestImageData.length / PER_PAGE);
    if (dir === 'next' && pestCurrentPage < totalPages) pestCurrentPage++;
    else if (dir === 'prev' && pestCurrentPage > 1) pestCurrentPage--;
    const tp = renderGallery('pestGallery', pestImageData, pestCurrentPage, generatePestSVG);
    const info = document.getElementById('pestPageInfo');
    if (info) info.textContent = `第 ${pestCurrentPage} / ${tp} 页`;
}

// 初始化画廊
setTimeout(() => {
    const ftp = renderGallery('fireGallery', fireImageData, 1, generateFireSVG);
    const fInfo = document.getElementById('firePageInfo');
    if (fInfo) fInfo.textContent = `第 1 / ${ftp} 页`;
    const ptp = renderGallery('pestGallery', pestImageData, 1, generatePestSVG);
    const pInfo = document.getElementById('pestPageInfo');
    if (pInfo) pInfo.textContent = `第 1 / ${ptp} 页`;
}, 300);

// ==================== 图像点击交互 ====================
function showImageInfo(el) {
    const lat = el.dataset.lat;
    const lng = el.dataset.lng;
    const source = el.dataset.source;
    const time = el.dataset.time;
    const result = el.dataset.result;
    const isHighRisk = el.classList.contains('high-risk');
    const modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.6);z-index:10000;display:flex;align-items:center;justify-content:center;';
    modal.innerHTML = `<div style="background:#1a2332;border:1px solid #2a3a4a;border-radius:10px;width:520px;max-height:80vh;overflow-y:auto;box-shadow:0 8px 32px rgba(0,0,0,0.5);">
        <div style="padding:16px 20px;border-bottom:1px solid #2a3a4a;display:flex;justify-content:space-between;align-items:center;">
            <h3 style="margin:0;color:#fff;font-size:16px;">图像详情</h3>
            <button onclick="this.closest('div[style]').parentElement.remove()" style="background:none;border:none;color:#8899aa;font-size:18px;cursor:pointer;">✕</button>
        </div>
        <div style="padding:16px 20px;">
            <div style="margin-bottom:12px;">${el.querySelector('svg').outerHTML.replace('style="width:100%;"', 'style="width:100%;border-radius:6px;border:1px solid #2a3a4a;"')}</div>
            <div style="display:flex;gap:8px;margin-bottom:12px;">
                <span style="background:${isHighRisk ? 'rgba(255,61,61,0.9)' : 'rgba(0,230,118,0.9)'};color:#fff;padding:4px 10px;border-radius:4px;font-size:12px;font-weight:600;">${result}</span>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px 16px;font-size:13px;">
                <div><span style="color:#8899aa;">纬度：</span><span style="color:#4fc3f7;">${lat}</span></div>
                <div><span style="color:#8899aa;">经度：</span><span style="color:#4fc3f7;">${lng}</span></div>
                <div><span style="color:#8899aa;">来源：</span><span style="color:#e0e6ed;">${source}</span></div>
                <div><span style="color:#8899aa;">时间：</span><span style="color:#e0e6ed;">${time}</span></div>
            </div>
            <div style="margin-top:16px;display:flex;gap:8px;">
                <button onclick="this.closest('div[style]').parentElement.parentElement.remove()" style="flex:1;padding:8px;background:#4fc3f7;color:#0a1929;border:none;border-radius:6px;font-size:13px;cursor:pointer;font-weight:600;">定位到地图</button>
                <button onclick="this.closest('div[style]').parentElement.parentElement.remove()" style="flex:1;padding:8px;background:#2a3a4a;color:#e0e6ed;border:1px solid #3a4a5a;border-radius:6px;font-size:13px;cursor:pointer;">关闭</button>
            </div>
        </div>
    </div>`;
    modal.addEventListener('click', function(e) { if (e.target === modal) modal.remove(); });
    document.body.appendChild(modal);
}

function runFireIdentify() {
    const btn = event.target;
    btn.textContent = '识别中...';
    btn.disabled = true;
    setTimeout(() => {
        btn.textContent = '执行AI识别';
        btn.disabled = false;
        const cards = document.querySelectorAll('#fireGallery .identify-card');
        cards.forEach(c => {
            c.style.transition = 'box-shadow 0.3s';
            c.style.boxShadow = '0 0 12px rgba(79,195,247,0.5)';
            setTimeout(() => { c.style.boxShadow = ''; }, 1500);
        });
    }, 2000);
}

function runRiskAssessment() {
    const btn = event.target;
    btn.textContent = '评估中...';
    btn.disabled = true;
    setTimeout(() => {
        btn.textContent = '执行风险评估';
        btn.disabled = false;
        alert('风险评估完成！已更新各林区风险等级。');
    }, 2000);
}

function exportRiskReport() {
    alert('评估报告已生成，正在导出PDF...');
}

function runPestIdentify() {
    const btn = event.target;
    btn.textContent = '识别中...';
    btn.disabled = true;
    setTimeout(() => {
        btn.textContent = '执行AI识别';
        btn.disabled = false;
        const cards = document.querySelectorAll('#pestGallery .identify-card');
        cards.forEach(c => {
            c.style.transition = 'box-shadow 0.3s';
            c.style.boxShadow = '0 0 12px rgba(79,195,247,0.5)';
            setTimeout(() => { c.style.boxShadow = ''; }, 1500);
        });
    }, 2000);
}

// ==================== 火点查看处置 ====================
// firePointData 已在 initAppData() 中异步加载

function viewFirePoint(fid) {
    const f = firePointData[fid];
    if (!f) return;
    const levelColor = f.level === '较大' ? '#ff3d3d' : '#ff9800';
    const modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.6);z-index:10000;display:flex;align-items:center;justify-content:center;';
    modal.innerHTML = `<div style="background:#1a2332;border:1px solid #2a3a4a;border-radius:10px;width:460px;max-height:80vh;overflow-y:auto;box-shadow:0 8px 32px rgba(0,0,0,0.5);">
        <div style="padding:16px 20px;border-bottom:1px solid #2a3a4a;display:flex;justify-content:space-between;align-items:center;">
            <h3 style="margin:0;color:#fff;font-size:16px;">火点详情 · ${f.id}</h3>
            <button onclick="this.closest('div[style]').parentElement.remove()" style="background:none;border:none;color:#8899aa;font-size:18px;cursor:pointer;">✕</button>
        </div>
        <div style="padding:16px 20px;">
            <div style="display:flex;gap:12px;margin-bottom:14px;">
                <span style="background:${levelColor};color:#fff;padding:4px 10px;border-radius:4px;font-size:12px;font-weight:600;">${f.level}</span>
                <span style="background:rgba(255,152,0,0.15);color:#ff9800;padding:4px 10px;border-radius:4px;font-size:12px;font-weight:600;">${f.status}</span>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px 16px;font-size:13px;">
                <div><span style="color:#8899aa;">位置：</span><span style="color:#e0e6ed;">${f.area}</span></div>
                <div><span style="color:#8899aa;">发现时间：</span><span style="color:#e0e6ed;">${f.time}</span></div>
                <div><span style="color:#8899aa;">经度：</span><span style="color:#e0e6ed;">${f.lng}</span></div>
                <div><span style="color:#8899aa;">纬度：</span><span style="color:#e0e6ed;">${f.lat}</span></div>
                <div><span style="color:#8899aa;">风向风速：</span><span style="color:#e0e6ed;">${f.wind}</span></div>
                <div><span style="color:#8899aa;">蔓延方向：</span><span style="color:#ff9800;">${f.spread}</span></div>
                <div><span style="color:#8899aa;">蔓延速度：</span><span style="color:#ff9800;">${f.speed}</span></div>
                <div><span style="color:#8899aa;">影响面积：</span><span style="color:#ff3d3d;">${f.affected}</span></div>
            </div>
            <div style="margin-top:14px;padding-top:14px;border-top:1px solid #2a3a4a;">
                <h4 style="margin:0 0 8px;color:#4fc3f7;font-size:13px;">处置信息</h4>
                <div style="font-size:13px;color:#e0e6ed;line-height:1.6;margin-bottom:8px;">${f.response}</div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px 16px;font-size:13px;">
                    <div><span style="color:#8899aa;">现场指挥：</span><span style="color:#e0e6ed;">${f.commander}</span></div>
                    <div><span style="color:#8899aa;">处置力量：</span><span style="color:#e0e6ed;">${f.forces}</span></div>
                </div>
            </div>
            <div style="margin-top:16px;display:flex;gap:8px;">
                <button onclick="this.closest('div[style]').parentElement.parentElement.remove()" style="flex:1;padding:8px;background:#4fc3f7;color:#0a1929;border:none;border-radius:6px;font-size:13px;cursor:pointer;font-weight:600;">定位到地图</button>
                <button onclick="this.closest('div[style]').parentElement.parentElement.remove()" style="flex:1;padding:8px;background:#2a3a4a;color:#e0e6ed;border:1px solid #3a4a5a;border-radius:6px;font-size:13px;cursor:pointer;">关闭</button>
            </div>
        </div>
    </div>`;
    modal.addEventListener('click', function(e) { if (e.target === modal) modal.remove(); });
    document.body.appendChild(modal);
}

// ==================== 页面五：统计报表 ====================
function initReportPage() {
    document.getElementById('page-report').innerHTML = `
    <div class="sub-tab-bar">
        <a class="sub-tab-item active" data-inner="inner-patrol-stat">巡护统计</a>
        <a class="sub-tab-item" data-inner="inner-performance">人员绩效</a>
        <a class="sub-tab-item" data-inner="inner-drone-stat">无人机统计</a>
        <a class="sub-tab-item" data-inner="inner-disaster-stat">灾害统计</a>
        <a class="sub-tab-item" data-inner="inner-report-export">报表导出</a>
    </div>
    <div class="content-full-panel">
        <div class="inner-tab active" id="inner-patrol-stat">
            <div class="stat-cards-row"><div class="mini-stat"><div class="mini-stat-value blue">1,286</div><div class="mini-stat-label">本月巡护次数</div></div><div class="mini-stat"><div class="mini-stat-value green">5,420h</div><div class="mini-stat-label">本月巡护时长</div></div><div class="mini-stat"><div class="mini-stat-value orange">15,680km</div><div class="mini-stat-label">本月巡护里程</div></div><div class="mini-stat"><div class="mini-stat-value purple">78.5%</div><div class="mini-stat-label">覆盖面积占比</div></div></div>
            <div class="chart-row"><div class="chart-card"><h3>月度巡护趋势</h3><div class="chart-placeholder"><div class="bar-chart"><div class="bar" style="height:40%"><span>1月</span></div><div class="bar" style="height:55%"><span>2月</span></div><div class="bar" style="height:65%"><span>3月</span></div><div class="bar" style="height:70%"><span>4月</span></div><div class="bar" style="height:80%"><span>5月</span></div><div class="bar active" style="height:90%"><span>6月</span></div></div></div></div><div class="chart-card"><h3>各林区巡护分布</h3><div class="chart-placeholder"><div class="donut-chart"><div class="donut"><div class="donut-label">1,286<br><small>总次数</small></div></div><div class="donut-legend"><span><i style="background:#00aaff;"></i>一号林区 28%</span><span><i style="background:#00e676;"></i>二号林区 25%</span><span><i style="background:#ff9800;"></i>三号林区 22%</span><span><i style="background:#b388ff;"></i>四号林区 15%</span><span><i style="background:#ff3d3d;"></i>五号林区 10%</span></div></div></div></div></div>
        </div>
        <div class="inner-tab" id="inner-performance"><div class="panel-card"><div class="card-header"><h3>人员绩效排行</h3><div class="card-actions"><select class="select-sm"><option>本月</option><option>本季度</option></select></div></div><div class="card-body"><table class="data-table"><thead><tr><th>排名</th><th>姓名</th><th>巡护次数</th><th>时长(h)</th><th>里程(km)</th><th>评分</th></tr></thead><tbody><tr class="rank-top"><td>1</td><td>张建国</td><td>28</td><td>112.5</td><td>345.6</td><td><span class="score high">98</span></td></tr><tr class="rank-top"><td>2</td><td>刘德才</td><td>26</td><td>98.3</td><td>312.8</td><td><span class="score high">95</span></td></tr><tr class="rank-top"><td>3</td><td>王大山</td><td>25</td><td>95.0</td><td>298.5</td><td><span class="score mid">92</span></td></tr><tr><td>4</td><td>李明辉</td><td>23</td><td>88.2</td><td>275.3</td><td><span class="score mid">88</span></td></tr><tr><td>5</td><td>赵文博</td><td>22</td><td>82.5</td><td>260.1</td><td><span class="score mid">85</span></td></tr></tbody></table></div></div></div>
        <div class="inner-tab" id="inner-drone-stat"><div class="stat-cards-row"><div class="mini-stat"><div class="mini-stat-value blue">86</div><div class="mini-stat-label">本月飞行次数</div></div><div class="mini-stat"><div class="mini-stat-value green">342h</div><div class="mini-stat-label">本月飞行时长</div></div><div class="mini-stat"><div class="mini-stat-value orange">2,156km</div><div class="mini-stat-label">本月飞行里程</div></div></div><div class="panel-card"><div class="card-header"><h3>无人机飞行统计</h3></div><div class="card-body"><table class="data-table"><thead><tr><th>编号</th><th>型号</th><th>飞行次数</th><th>飞行时长</th><th>飞行里程</th><th>状态</th></tr></thead><tbody><tr><td>UAV-01</td><td>大疆M300</td><td>22</td><td>86h</td><td>540km</td><td><span class="tag tag-green">正常</span></td></tr><tr><td>UAV-02</td><td>大疆M300</td><td>18</td><td>72h</td><td>465km</td><td><span class="tag tag-green">正常</span></td></tr><tr><td>UAV-03</td><td>大疆M350</td><td>20</td><td>80h</td><td>510km</td><td><span class="tag tag-green">正常</span></td></tr></tbody></table></div></div></div>
        <div class="inner-tab" id="inner-disaster-stat"><div class="stat-cards-row"><div class="mini-stat"><div class="mini-stat-value red">23</div><div class="mini-stat-label">本月火情数</div></div><div class="mini-stat"><div class="mini-stat-value orange">45</div><div class="mini-stat-label">本月病害数</div></div><div class="mini-stat"><div class="mini-stat-value purple">18</div><div class="mini-stat-label">本月异常事件</div></div></div><div class="chart-row"><div class="chart-card"><h3>月度灾害趋势</h3><div class="chart-placeholder"><div class="bar-chart"><div class="bar" style="height:30%;background:#ff3d3d;"><span>1月</span></div><div class="bar" style="height:45%;background:#ff3d3d;"><span>2月</span></div><div class="bar" style="height:55%;background:#ff3d3d;"><span>3月</span></div><div class="bar" style="height:70%;background:#ff3d3d;"><span>4月</span></div><div class="bar" style="height:85%;background:#ff3d3d;"><span>5月</span></div><div class="bar active" style="height:60%;background:#ff3d3d;"><span>6月</span></div></div></div></div><div class="chart-card"><h3>灾害类型占比</h3><div class="chart-placeholder"><div class="donut-chart"><div class="donut"><div class="donut-label">86<br><small>总事件</small></div></div><div class="donut-legend"><span><i style="background:#ff3d3d;"></i>火情 27%</span><span><i style="background:#ff9800;"></i>病害 52%</span><span><i style="background:#b388ff;"></i>异常 21%</span></div></div></div></div></div></div>
        <div class="inner-tab" id="inner-report-export"><div class="content-full-panel"><div class="panel-card"><div class="card-header"><h3>报表导出</h3></div><div class="card-body"><div class="export-grid">
            <div class="export-card"><div class="export-icon">📊</div><h4>巡护报表</h4><p>巡护次数、时长、里程、覆盖面积统计</p><div class="export-actions"><button class="btn btn-primary btn-sm">导出Excel</button><button class="btn btn-outline btn-sm">导出PDF</button></div></div>
            <div class="export-card"><div class="export-icon">🔥</div><h4>火情报表</h4><p>火情数量、等级分布、处置情况统计</p><div class="export-actions"><button class="btn btn-primary btn-sm">导出Excel</button><button class="btn btn-outline btn-sm">导出PDF</button></div></div>
            <div class="export-card"><div class="export-icon">🐛</div><h4>病害报表</h4><p>病虫害分布、感染面积、处置进度统计</p><div class="export-actions"><button class="btn btn-primary btn-sm">导出Excel</button><button class="btn btn-outline btn-sm">导出PDF</button></div></div>
            <div class="export-card"><div class="export-icon">📋</div><h4>综合报表</h4><p>巡护+灾害+绩效综合统计报表</p><div class="export-actions"><button class="btn btn-primary btn-sm">导出Excel</button><button class="btn btn-outline btn-sm">导出PDF</button></div></div>
        </div></div></div></div></div>
    </div>`;
}

function initSystemPage() {
    const isGuest = currentUser && currentUser.role === 'guest';
    if (isGuest) return;
    document.getElementById('page-system').innerHTML = `
    <div class="sub-tab-bar">
        <a class="sub-tab-item active" data-inner="inner-user-account">用户账号</a>
        <a class="sub-tab-item" data-inner="inner-role-config">角色配置</a>
        <a class="sub-tab-item" data-inner="inner-permission">权限分配</a>
        <a class="sub-tab-item" data-inner="inner-map-service">地图服务</a>
        <a class="sub-tab-item" data-inner="inner-data-ops">数据运维</a>
        <a class="sub-tab-item" data-inner="inner-log-mgmt">日志管理</a>
        <a class="sub-tab-item" data-inner="inner-sys-monitor">系统监控</a>
    </div>
    <div class="content-full-panel">
        <div class="inner-tab active" id="inner-user-account"><div class="panel-card"><div class="card-header"><h3>用户账号管理</h3><div class="card-actions"><button class="btn btn-primary">新增用户</button></div></div><div class="card-body"><table class="data-table"><thead><tr><th>用户名</th><th>姓名</th><th>角色</th><th>部门</th><th>状态</th><th>操作</th></tr></thead><tbody><tr><td>admin</td><td>系统管理员</td><td>超级管理员</td><td>信息中心</td><td><span class="tag tag-green">启用</span></td><td><a class="link-btn">编辑</a></td></tr><tr><td>zhangjg</td><td>张建国</td><td>护林员</td><td>巡护一队</td><td><span class="tag tag-green">启用</span></td><td><a class="link-btn">编辑</a><a class="link-btn">删除</a></td></tr><tr><td>dispatch</td><td>调度员</td><td>调度员</td><td>指挥中心</td><td><span class="tag tag-green">启用</span></td><td><a class="link-btn">编辑</a><a class="link-btn">删除</a></td></tr></tbody></table></div></div></div>
        <div class="inner-tab" id="inner-role-config"><div class="panel-card"><div class="card-header"><h3>角色配置</h3><div class="card-actions"><button class="btn btn-primary">新增角色</button></div></div><div class="card-body"><table class="data-table"><thead><tr><th>角色名称</th><th>描述</th><th>用户数</th><th>操作</th></tr></thead><tbody><tr><td>超级管理员</td><td>系统最高权限</td><td>1</td><td><a class="link-btn">编辑</a></td></tr><tr><td>调度员</td><td>任务派发、监控调度</td><td>3</td><td><a class="link-btn">编辑</a><a class="link-btn">删除</a></td></tr><tr><td>护林员</td><td>巡护执行、日志填报</td><td>18</td><td><a class="link-btn">编辑</a><a class="link-btn">删除</a></td></tr><tr><td>无人机操作员</td><td>无人机操控、数据采集</td><td>4</td><td><a class="link-btn">编辑</a><a class="link-btn">删除</a></td></tr></tbody></table></div></div></div>
        <div class="inner-tab" id="inner-permission"><div class="panel-card"><div class="card-header"><h3>权限分配</h3></div><div class="card-body"><table class="data-table"><thead><tr><th>角色</th><th>综合驾驶舱</th><th>资源与巡护</th><th>监控与处置</th><th>统计报表</th><th>系统管理</th></tr></thead><tbody><tr><td>超级管理员</td><td><span class="tag tag-green">全部</span></td><td><span class="tag tag-green">全部</span></td><td><span class="tag tag-green">全部</span></td><td><span class="tag tag-green">全部</span></td><td><span class="tag tag-green">全部</span></td></tr><tr><td>调度员</td><td><span class="tag tag-green">查看</span></td><td><span class="tag tag-green">全部</span></td><td><span class="tag tag-green">全部</span></td><td><span class="tag tag-blue">查看</span></td><td><span class="tag tag-gray">无</span></td></tr><tr><td>护林员</td><td><span class="tag tag-blue">查看</span></td><td><span class="tag tag-orange">部分</span></td><td><span class="tag tag-orange">部分</span></td><td><span class="tag tag-gray">无</span></td><td><span class="tag tag-gray">无</span></td></tr><tr><td>无人机操作员</td><td><span class="tag tag-blue">查看</span></td><td><span class="tag tag-orange">部分</span></td><td><span class="tag tag-green">全部</span></td><td><span class="tag tag-gray">无</span></td><td><span class="tag tag-gray">无</span></td></tr></tbody></table></div></div></div>
        <div class="inner-tab" id="inner-map-service"><div class="panel-card"><div class="card-header"><h3>GeoServer 地图服务管理</h3><div class="card-actions"><button class="btn btn-primary">发布图层</button></div></div><div class="card-body"><table class="data-table"><thead><tr><th>工作空间</th><th>图层名称</th><th>类型</th><th>状态</th><th>操作</th></tr></thead><tbody><tr><td>forest</td><td>林场边界</td><td>WMS</td><td><span class="tag tag-green">正常</span></td><td><a class="link-btn">配置</a><a class="link-btn">预览</a></td></tr><tr><td>forest</td><td>林班小班</td><td>WMS</td><td><span class="tag tag-green">正常</span></td><td><a class="link-btn">配置</a><a class="link-btn">预览</a></td></tr><tr><td>forest</td><td>DEM地形</td><td>WMS</td><td><span class="tag tag-green">正常</span></td><td><a class="link-btn">配置</a><a class="link-btn">预览</a></td></tr><tr><td>imagery</td><td>卫星影像</td><td>WMTS</td><td><span class="tag tag-green">正常</span></td><td><a class="link-btn">配置</a><a class="link-btn">预览</a></td></tr></tbody></table></div></div></div>
        <div class="inner-tab" id="inner-data-ops"><div class="panel-card"><div class="card-header"><h3>数据运维</h3><div class="card-actions"><button class="btn btn-primary">数据导入</button><button class="btn btn-outline">数据备份</button></div></div><div class="card-body"><table class="data-table"><thead><tr><th>操作类型</th><th>数据集</th><th>执行时间</th><th>状态</th><th>操作</th></tr></thead><tbody><tr><td>备份</td><td>全量备份</td><td>2026-06-08 02:00</td><td><span class="tag tag-green">成功</span></td><td><a class="link-btn">恢复</a></td></tr><tr><td>备份</td><td>增量备份</td><td>2026-06-07 02:00</td><td><span class="tag tag-green">成功</span></td><td><a class="link-btn">恢复</a></td></tr><tr><td>导入</td><td>林班小班数据</td><td>2026-06-06 10:30</td><td><span class="tag tag-green">成功</span></td><td><a class="link-btn">查看</a></td></tr></tbody></table></div></div></div>
        <div class="inner-tab" id="inner-log-mgmt"><div class="panel-card"><div class="card-header"><h3>日志管理</h3></div><div class="card-body"><div class="search-bar"><select><option>全部类型</option><option>登录日志</option><option>操作日志</option><option>异常日志</option></select><input type="date"/><button class="btn btn-sm">查询</button></div><table class="data-table"><thead><tr><th>时间</th><th>类型</th><th>用户</th><th>内容</th><th>IP</th></tr></thead><tbody><tr><td>16:35</td><td>操作</td><td>admin</td><td>查看火情详情 F001</td><td>192.168.1.10</td></tr><tr><td>16:10</td><td>操作</td><td>dispatch</td><td>派发巡护任务至王大山</td><td>192.168.1.11</td></tr><tr><td>15:52</td><td>异常</td><td>系统</td><td>护林员轨迹偏离告警</td><td>-</td></tr><tr><td>08:00</td><td>登录</td><td>admin</td><td>用户登录系统</td><td>192.168.1.10</td></tr></tbody></table></div></div></div>
        <div class="inner-tab" id="inner-sys-monitor"><div class="panel-card"><div class="card-header"><h3>系统监控</h3></div><div class="card-body"><div class="stat-cards-row"><div class="mini-stat"><div class="mini-stat-value green">正常</div><div class="mini-stat-label">服务状态</div></div><div class="mini-stat"><div class="mini-stat-value green">正常</div><div class="mini-stat-label">数据库状态</div></div><div class="mini-stat"><div class="mini-stat-value blue">45%</div><div class="mini-stat-label">CPU使用率</div></div><div class="mini-stat"><div class="mini-stat-value orange">68%</div><div class="mini-stat-label">内存使用率</div></div></div><table class="data-table"><thead><tr><th>服务名称</th><th>端口</th><th>运行时长</th><th>状态</th></tr></thead><tbody><tr><td>Web应用服务</td><td>8080</td><td>15天3小时</td><td><span class="tag tag-green">运行中</span></td></tr><tr><td>GeoServer</td><td>8090</td><td>15天3小时</td><td><span class="tag tag-green">运行中</span></td></tr><tr><td>PostgreSQL</td><td>5432</td><td>15天3小时</td><td><span class="tag tag-green">运行中</span></td></tr><tr><td>Redis缓存</td><td>6379</td><td>15天3小时</td><td><span class="tag tag-green">运行中</span></td></tr></tbody></table></div></div></div>
    </div>`;
}
